<?php
$phpVersion = PHP_VERSION;
$extensions = get_loaded_extensions();
sort($extensions);

$dbOk = false;
$dbVersion = '';
$dbError = '';
try {
    $pdo = new PDO('mysql:host=db;port=3306;charset=utf8mb4', 'dev', 'dev', [
        PDO::ATTR_TIMEOUT => 2,
    ]);
    $dbVersion = (string) $pdo->query('SELECT VERSION()')->fetchColumn();
    $dbOk = true;
} catch (Throwable $e) {
    $dbError = $e->getMessage();
}

$redisOk = false;
$redisHasExt = class_exists('Redis');
$redisError = '';
if ($redisHasExt) {
    try {
        $redis = new Redis();
        $redis->connect('redis', 6379, 1.5);
        $redis->ping();
        $redisOk = true;
    } catch (Throwable $e) {
        $redisError = $e->getMessage();
    }
}

$lang = 'ru';
if (isset($_GET['lang']) && in_array($_GET['lang'], ['ru', 'en'], true)) {
    $lang = $_GET['lang'];
} elseif (!empty($_SERVER['HTTP_ACCEPT_LANGUAGE']) && stripos($_SERVER['HTTP_ACCEPT_LANGUAGE'], 'ru') === false) {
    $lang = 'en';
}

$host = $_SERVER['HTTP_HOST'] ?? 'test1.loc';
$statusData = [
    'phpVersion' => $phpVersion,
    'dbOk' => $dbOk,
    'dbVersion' => $dbVersion,
    'dbError' => $dbError,
    'redisOk' => $redisOk,
    'redisHasExt' => $redisHasExt,
    'redisError' => $redisError,
    'extCount' => count($extensions),
    'initialLang' => $lang,
    'forcedLang' => isset($_GET['lang']) && in_array($_GET['lang'], ['ru', 'en'], true) ? $_GET['lang'] : null,
];
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($host) ?> — LocalDockerServer Demo (PHP <?= htmlspecialchars($phpVersion) ?>)</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0b1120; color: #e2e8f0; padding: 40px 20px; }
        .wrap { max-width: 820px; margin: 0 auto; }
        .card { background: #161f33; border: 1px solid #263248; border-radius: 16px; padding: 28px; margin-bottom: 18px; }
        .card-top { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; margin-bottom: 12px; }
        .badge { display: inline-block; background: #2563eb; color: #fff; font-size: 12px; font-weight: 700; padding: 4px 12px; border-radius: 999px; }
        .lang-switch { display: inline-flex; background: #0b1120; border: 1px solid #263248; border-radius: 9px; padding: 3px; gap: 3px; }
        .lang-btn { border: none; background: transparent; color: #94a3b8; font-size: 12px; font-weight: 700; padding: 5px 10px; border-radius: 6px; cursor: pointer; transition: all 0.15s; }
        .lang-btn:hover { color: #f8fafc; }
        .lang-btn.active { background: #2563eb; color: #fff; }
        h1 { font-size: 28px; margin-bottom: 8px; }
        .sub { color: #94a3b8; margin-bottom: 20px; line-height: 1.55; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; }
        .box { background: #0b1120; border: 1px solid #263248; border-radius: 12px; padding: 16px; }
        .label { font-size: 11px; color: #94a3b8; text-transform: uppercase; letter-spacing: .05em; }
        .val { font-size: 18px; font-weight: 700; margin-top: 6px; }
        .ok { color: #4ade80; }
        .err { color: #f87171; }
        .links { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 20px; }
        .btn { text-decoration: none; background: #1e293b; border: 1px solid #334155; color: #f8fafc; padding: 9px 14px; border-radius: 10px; font-size: 13px; font-weight: 600; }
        .btn:hover { background: #334155; }
        .ext { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 12px; }
        .ext span { background: #0b1120; border: 1px solid #263248; padding: 3px 8px; border-radius: 6px; font-size: 12px; color: #cbd5e1; }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="card">
            <div class="card-top">
                <span class="badge" id="t-badge">LocalDockerServer • Демо-проект</span>
                <div class="lang-switch" role="group" aria-label="Language">
                    <button type="button" class="lang-btn" data-lang="ru">RU</button>
                    <button type="button" class="lang-btn" data-lang="en">EN</button>
                </div>
            </div>
            <h1><?= htmlspecialchars($host) ?></h1>
            <p class="sub" id="t-sub"></p>
            <div class="grid">
                <div class="box">
                    <div class="label" id="t-php-label">Текущая версия PHP</div>
                    <div class="val" style="color:#60a5fa">PHP <?= htmlspecialchars($phpVersion) ?></div>
                </div>
                <div class="box">
                    <div class="label" id="t-db-label">База данных (MariaDB)</div>
                    <div class="val <?= $dbOk ? 'ok' : 'err' ?>" id="t-db-status" style="font-size:14px"></div>
                </div>
                <div class="box">
                    <div class="label" id="t-redis-label">Redis</div>
                    <div class="val <?= $redisOk ? 'ok' : 'err' ?>" id="t-redis-status" style="font-size:14px"></div>
                </div>
            </div>
            <div class="links">
                <a class="btn" href="http://panel.loc" id="t-link-panel">⚙️ Панель управления</a>
                <a class="btn" href="http://pma.loc">🗄️ phpMyAdmin</a>
                <a class="btn" href="http://mail.loc">✉️ Mailpit</a>
            </div>
        </div>
        <div class="card">
            <div class="label" id="t-ext-label">Загруженные расширения PHP (<?= count($extensions) ?>)</div>
            <div class="ext">
                <?php foreach ($extensions as $ext): ?>
                    <span><?= htmlspecialchars($ext) ?></span>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <script>
        const DATA = <?= json_encode($statusData, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;

        const TEXTS = {
            ru: {
                badge: 'LocalDockerServer • Демо-проект',
                sub: 'Этот проект работает на <strong>PHP ' + DATA.phpVersion + '</strong> (устанавливается при первом запуске). Остальные версии PHP (7.4, 8.1, 8.2, 8.3) можно дозагрузить в один клик в панели управления и переключать для любого сайта.',
                phpLabel: 'Текущая версия PHP',
                dbLabel: 'База данных (MariaDB)',
                redisLabel: 'Redis',
                dbConnected: 'Подключено (MariaDB ' + DATA.dbVersion + ')',
                dbError: 'Ошибка: ' + DATA.dbError,
                redisConnected: 'Подключено (PONG)',
                redisNoExt: 'Расширение не загружено',
                redisError: 'Ошибка: ' + DATA.redisError,
                linkPanel: '⚙️ Панель управления',
                extLabel: 'Загруженные расширения PHP (' + DATA.extCount + ')',
            },
            en: {
                badge: 'LocalDockerServer • Demo Project',
                sub: 'This project is running on <strong>PHP ' + DATA.phpVersion + '</strong> (installed on first launch). Other PHP versions (7.4, 8.1, 8.2, 8.3) can be downloaded in one click from the control panel and switched per site.',
                phpLabel: 'Current PHP Version',
                dbLabel: 'Database (MariaDB)',
                redisLabel: 'Redis',
                dbConnected: 'Connected (MariaDB ' + DATA.dbVersion + ')',
                dbError: 'Error: ' + DATA.dbError,
                redisConnected: 'Connected (PONG)',
                redisNoExt: 'Extension not loaded',
                redisError: 'Error: ' + DATA.redisError,
                linkPanel: '⚙️ Control Panel',
                extLabel: 'Loaded PHP Extensions (' + DATA.extCount + ')',
            },
        };

        function applyLang(lang) {
            const l = lang === 'en' ? 'en' : 'ru';
            const t = TEXTS[l];
            document.documentElement.lang = l;
            document.getElementById('t-badge').textContent = t.badge;
            document.getElementById('t-sub').innerHTML = t.sub;
            document.getElementById('t-php-label').textContent = t.phpLabel;
            document.getElementById('t-db-label').textContent = t.dbLabel;
            document.getElementById('t-redis-label').textContent = t.redisLabel;
            document.getElementById('t-db-status').textContent = DATA.dbOk ? t.dbConnected : t.dbError;
            document.getElementById('t-redis-status').textContent = DATA.redisOk
                ? t.redisConnected
                : (DATA.redisHasExt ? t.redisError : t.redisNoExt);
            document.getElementById('t-link-panel').textContent = t.linkPanel;
            document.getElementById('t-ext-label').textContent = t.extLabel;

            document.querySelectorAll('.lang-btn').forEach((btn) => {
                btn.classList.toggle('active', btn.dataset.lang === l);
            });
            try {
                localStorage.setItem('lds_test1_lang', l);
            } catch (e) {}
        }

        document.querySelectorAll('.lang-btn').forEach((btn) => {
            btn.addEventListener('click', () => applyLang(btn.dataset.lang));
        });

        let startLang = DATA.forcedLang;
        if (!startLang) {
            try {
                startLang = localStorage.getItem('lds_test1_lang');
            } catch (e) {}
        }
        applyLang(startLang || DATA.initialLang);
    </script>
</body>
</html>
