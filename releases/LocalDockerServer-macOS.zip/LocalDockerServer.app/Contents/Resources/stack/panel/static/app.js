const state = {
    lang: localStorage.getItem('lds_lang') || 'ru',
    overview: null,
    dnsSsl: null,
    nativeHost: window.ldsNativeHost || null,
    activeTab: 'projects',
    logsTarget: null, // { kind: 'service' | 'project', id, logType }
    installWatch: null, // { version, timer, pendingProjectFolder }
};

function t(key, params = {}) {
    const dict = I18N[state.lang] || I18N.ru;
    let str = dict[key] ?? I18N.ru[key] ?? key;
    for (const [k, v] of Object.entries(params)) {
        str = str.replaceAll(`{${k}}`, String(v));
    }
    return str;
}

function escapeHtml(str) {
    return String(str ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function postNative(payload) {
    if (window.webkit?.messageHandlers?.localdockerserver) {
        window.webkit.messageHandlers.localdockerserver.postMessage(payload);
        return true;
    }
    return false;
}

function isNativeApp() {
    return Boolean(state.nativeHost?.isApp || window.webkit?.messageHandlers?.localdockerserver);
}

function applyStaticTranslations() {
    document.documentElement.lang = state.lang;
    document.title = t('page.title');

    document.querySelectorAll('[data-i18n]').forEach((el) => {
        el.textContent = t(el.dataset.i18n);
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
        el.placeholder = t(el.dataset.i18nPlaceholder);
    });
    document.querySelectorAll('[data-i18n-title]').forEach((el) => {
        el.title = t(el.dataset.i18nTitle);
    });

    const tld = state.overview?.default_tld || state.nativeHost?.env?.default_tld || 'loc';
    const statSslHint = document.getElementById('stat-ssl-hint');
    if (statSslHint) statSslHint.textContent = t('stats.sslHint', { tld });

    const createHint = document.getElementById('create-name-hint');
    if (createHint) createHint.innerHTML = t('modal.create.nameHint', { tld });

    const dnsHeading = document.getElementById('settings-dns-heading');
    if (dnsHeading) dnsHeading.textContent = t('settings.dnsTitle', { tld });

    const dnsDesc = document.getElementById('settings-dns-desc');
    if (dnsDesc) dnsDesc.innerHTML = t('settings.dnsDesc', { tld });

    const resolverNote = document.getElementById('settings-resolver-note');
    if (resolverNote) {
        resolverNote.innerHTML = t('settings.resolverNote', { tld });
        if (state.dnsSsl?.resolver_path) {
            const rp = document.getElementById('resolver-path');
            if (rp) rp.textContent = state.dnsSsl.resolver_path;
        }
    }

    const sslDesc = document.getElementById('settings-ssl-desc');
    if (sslDesc) sslDesc.innerHTML = t('settings.sslDesc', { tld });

    const hostsDesc = document.getElementById('settings-hosts-desc');
    if (hostsDesc) hostsDesc.innerHTML = t('settings.hostsDesc');

    const langSelect = document.getElementById('setting-language');
    if (langSelect) langSelect.value = state.lang;

    updateTabHeader();
}

function updateTabHeader() {
    document.getElementById('page-title').textContent = t(`tab.${state.activeTab}.title`);
    document.getElementById('page-subtitle').textContent = t(`tab.${state.activeTab}.sub`);
}

async function setLanguage(lang, fromNative = false) {
    if (lang !== 'ru' && lang !== 'en') return;
    const changed = state.lang !== lang;
    state.lang = lang;
    localStorage.setItem('lds_lang', lang);

    applyStaticTranslations();
    if (state.overview) {
        renderStats(state.overview);
        renderProjects(state.overview);
        renderServices(state.overview);
        populateSelects(state.overview);
        renderPhpManager(state.overview);
    }
    if (state.activeTab === 'databases') loadDatabases();
    if (state.activeTab === 'settings') renderSettingsUI();

    if (!fromNative && changed) {
        try {
            await api('/api/settings', {
                method: 'PATCH',
                body: JSON.stringify({ language: lang }),
            });
        } catch {
            // ignore backend sync errors if offline
        }
        postNative({ action: 'setLanguage', language: lang });
        showToast(t('settings.languageSaved'), 'success');
    }
}

window.setAppLanguage = (lang, fromNative = true) => {
    setLanguage(lang, fromNative);
};

window.onLdsNativeState = (hostState) => {
    state.nativeHost = hostState;
    if (hostState?.language && hostState.language !== state.lang) {
        setLanguage(hostState.language, true);
    }
    renderSettingsUI();
};

window.onLdsNativeActionResult = (res) => {
    if (!res) return;
    showToast(res.message || (res.ok ? 'OK' : 'Error'), res.ok ? 'success' : 'error');
    if (state.activeTab === 'settings') {
        loadDnsSsl();
    }
};

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.textContent = message;
    container.appendChild(el);
    setTimeout(() => {
        el.remove();
    }, 4500);
}

async function api(url, options = {}) {
    const resp = await fetch(url, {
        headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
        ...options,
    });
    const text = await resp.text();
    let data = {};
    try {
        data = text ? JSON.parse(text) : {};
    } catch {
        data = { detail: text };
    }
    if (!resp.ok) {
        throw new Error(data.detail || data.message || `HTTP ${resp.status}`);
    }
    return data;
}

function copyText(text) {
    navigator.clipboard.writeText(text).then(
        () => showToast(t('common.copied'), 'success'),
        () => showToast(t('common.copyFailed'), 'error'),
    );
}

// ==========================================
// Навигация по вкладкам
// ==========================================
function switchTab(tab) {
    state.activeTab = tab;
    document.querySelectorAll('.nav-item').forEach((btn) => {
        btn.classList.toggle('active', btn.dataset.tab === tab);
    });
    document.querySelectorAll('.tab-panel').forEach((panel) => {
        panel.classList.toggle('active', panel.id === `tab-${tab}`);
    });
    updateTabHeader();

    if (tab === 'databases') loadDatabases();
    if (tab === 'php') loadPhpIni();
    if (tab === 'settings') {
        renderSettingsUI();
        loadDnsSsl();
        postNative({ action: 'getNativeState' });
    }
}

// ==========================================
// Загрузка обзора
// ==========================================
async function loadOverview() {
    try {
        const data = await api('/api/overview');
        state.overview = data;

        const serverLang = data.settings?.language;
        if (!state.nativeHost && serverLang && (serverLang === 'ru' || serverLang === 'en') && serverLang !== state.lang) {
            state.lang = serverLang;
            localStorage.setItem('lds_lang', serverLang);
            applyStaticTranslations();
        } else {
            applyStaticTranslations();
        }

        renderStats(data);
        renderProjects(data);
        renderServices(data);
        populateSelects(data);
        renderPhpManager(data);
        if (state.activeTab === 'settings') {
            renderSettingsUI();
        }
    } catch (err) {
        showToast(t('common.loadError', { err: err.message }), 'error');
    }
}

function renderStats(data) {
    const s = data.stats;
    document.getElementById('stat-projects').textContent = s.projects_total;
    document.getElementById('stat-projects-hint').textContent = t('stats.projectsActive', { n: s.projects_enabled });
    document.getElementById('stat-services').textContent = `${s.services_running} / ${s.services_installed}`;
    document.getElementById('stat-php').textContent = `${s.php_installed_count} / ${s.php_total_count}`;
    document.getElementById('stat-php-hint').textContent = t('stats.phpRunning', { n: s.php_running_count });
    document.getElementById('stat-ssl').textContent = data.ssl.ready ? t('stats.sslActive') : t('stats.sslNotCreated');

    document.getElementById('nav-projects-count').textContent = s.projects_total;
    document.getElementById('nav-services-count').textContent = `${s.services_running}/${s.services_installed}`;

    const pill = document.getElementById('docker-status-pill');
    if (data.docker_available) {
        pill.innerHTML = `<span class="dot ok"></span><span>${escapeHtml(t('sidebar.dockerConnected'))}</span>`;
    } else {
        pill.innerHTML = `<span class="dot err"></span><span>${escapeHtml(t('sidebar.dockerUnavailable'))}</span>`;
    }

    const tld = data.default_tld || 'loc';
    document.getElementById('stat-ssl-hint').textContent = t('stats.sslHint', { tld });

    const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    document.getElementById('link-pma').href = isLocalhost
        ? `http://localhost:${data.ports.pma}`
        : `http://pma.${tld}`;
    document.getElementById('link-mail').href = isLocalhost
        ? `http://localhost:${data.ports.mailpit}`
        : `http://mail.${tld}`;
}

function populateSelects(data) {
    const versions = Object.entries(data.php_versions);
    const optionsHtml = versions
        .map(([ver, info]) => {
            const suffix = info.installing
                ? t('projects.phpInstalling')
                : !info.installed
                    ? t('projects.phpNeedDownload')
                    : '';
            return `<option value="${ver}">${escapeHtml(info.label + suffix)}</option>`;
        })
        .join('');

    for (const id of ['create-php', 'edit-php']) {
        const el = document.getElementById(id);
        const current = el.value;
        el.innerHTML = optionsHtml;
        el.value = current && data.php_versions[current] ? current : data.default_php;
    }

    const consolePhp = document.getElementById('console-php');
    const prevConsolePhp = consolePhp.value;
    consolePhp.innerHTML = versions
        .map(([ver, info]) => {
            const mark = info.installed ? '' : t('projects.phpNotInstalled');
            return `<option value="${ver}" ${!info.installed ? 'disabled' : ''}>${escapeHtml(info.label + mark)}</option>`;
        })
        .join('');
    if (prevConsolePhp && data.php_versions[prevConsolePhp]?.installed) {
        consolePhp.value = prevConsolePhp;
    } else {
        const firstInstalled = versions.find(([, info]) => info.installed)?.[0] || data.default_php;
        consolePhp.value = firstInstalled;
    }

    const consoleProj = document.getElementById('console-project');
    const prevProj = consoleProj.value;
    consoleProj.innerHTML =
        `<option value="">${escapeHtml(t('console.rootOption'))}</option>` +
        data.projects
            .map((p) => `<option value="${escapeHtml(p.folder)}">${escapeHtml(p.folder)} (${escapeHtml(p.domain)})</option>`)
            .join('');
    if (prevProj) consoleProj.value = prevProj;
}

// ==========================================
// Установка и удаление версий PHP по требованию
// ==========================================
async function startPhpInstall(version, pendingProjectFolder = null) {
    try {
        await api(`/api/php/${encodeURIComponent(version)}/install`, { method: 'POST' });
        showToast(t('php.installStarted', { ver: version }), 'info');
        openPhpInstallModal(version, pendingProjectFolder);
        loadOverview();
    } catch (err) {
        showToast(t('php.installStartError', { ver: version, err: err.message }), 'error');
    }
}

function stopInstallPolling() {
    if (state.installWatch?.timer) {
        clearInterval(state.installWatch.timer);
    }
    state.installWatch = null;
}

function openPhpInstallModal(version, pendingProjectFolder = null) {
    stopInstallPolling();
    document.getElementById('php-install-title').textContent = t('php.installTitle', { ver: version });
    document.getElementById('php-install-logs').textContent = t('php.installConnecting');
    openModal('modal-php-install');

    const watch = { version, timer: null, pendingProjectFolder };
    state.installWatch = watch;

    const poll = async () => {
        try {
            const res = await api(`/api/php/${encodeURIComponent(version)}/install/status`);
            const pre = document.getElementById('php-install-logs');
            const badge = document.getElementById('php-install-badge');
            pre.textContent = (res.logs && res.logs.length) ? res.logs.join('\n') : t('php.installWaitingLogs');
            pre.scrollTop = pre.scrollHeight;

            if (res.status === 'installing') {
                badge.className = 'status-badge status-installing';
                badge.textContent = t('php.statusInstalling');
            } else if (res.status === 'done' || res.running) {
                badge.className = 'status-badge status-running';
                badge.textContent = t('php.installDoneBadge');
                clearInterval(watch.timer);
                watch.timer = null;

                if (watch.pendingProjectFolder) {
                    const folder = watch.pendingProjectFolder;
                    watch.pendingProjectFolder = null;
                    try {
                        await api(`/api/projects/${encodeURIComponent(folder)}`, {
                            method: 'PATCH',
                            body: JSON.stringify({ php_version: version }),
                        });
                        showToast(t('php.installSwitched', { ver: version, folder }), 'success');
                    } catch (err) {
                        showToast(t('php.installSwitchErr', { ver: version, err: err.message }), 'error');
                    }
                } else {
                    showToast(t('php.installDoneToast', { ver: version }), 'success');
                }
                await loadOverview();
            } else if (res.status === 'error') {
                badge.className = 'status-badge status-error';
                badge.textContent = t('php.installErrorBadge');
                clearInterval(watch.timer);
                watch.timer = null;
                showToast(t('php.installErrToast', { ver: version, err: res.error || 'log' }), 'error');
                await loadOverview();
            }
        } catch (err) {
            clearInterval(watch.timer);
            watch.timer = null;
        }
    };

    poll();
    watch.timer = setInterval(poll, 1400);
}

async function handleUninstallPhp(version) {
    if (!confirm(t('php.confirmUninstall', { ver: version }))) {
        return;
    }
    try {
        await api(`/api/php/${encodeURIComponent(version)}/uninstall`, { method: 'DELETE' });
        showToast(t('php.uninstalled', { ver: version }), 'success');
        await loadOverview();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// ==========================================
// Проекты
// ==========================================
function renderProjects(data) {
    const tbody = document.getElementById('projects-tbody');
    const query = (document.getElementById('project-search').value || '').trim().toLowerCase();
    const list = data.projects.filter(
        (p) => !query || p.domain.toLowerCase().includes(query) || p.folder.toLowerCase().includes(query),
    );

    if (!list.length) {
        tbody.innerHTML = `<tr><td colspan="6" class="empty">${t('projects.empty')}</td></tr>`;
        return;
    }

    const versions = Object.entries(data.php_versions);

    tbody.innerHTML = list
        .map((p) => {
            const phpInfo = data.php_versions[p.php_version];
            const phpOptions = versions
                .map(([v, info]) => {
                    const tag = info.installing
                        ? t('projects.phpInstalling')
                        : !info.installed
                            ? t('projects.phpDownload')
                            : '';
                    return `<option value="${v}" ${v === p.php_version ? 'selected' : ''}>PHP ${v}${escapeHtml(tag)}</option>`;
                })
                .join('');
            const rootLabel = p.public_dir ? `/${escapeHtml(p.public_dir)}` : escapeHtml(t('projects.rootLabel'));
            let statusHtml = p.enabled
                ? `<span class="status-badge status-running">${escapeHtml(t('projects.statusActive'))}</span>`
                : `<span class="status-badge status-stopped">${escapeHtml(t('projects.statusDisabled'))}</span>`;
            if (p.enabled && phpInfo && !phpInfo.installed) {
                statusHtml = `<button class="btn btn-sm btn-primary btn-install-php-inline" data-version="${escapeHtml(p.php_version)}" data-folder="${escapeHtml(p.folder)}">${escapeHtml(t('projects.installPhpInline', { ver: p.php_version }))}</button>`;
            }

            return `
            <tr>
                <td>
                    <div class="domain-cell">
                        <span class="domain-title">${escapeHtml(p.domain)}</span>
                        <span class="folder-sub">projects/${escapeHtml(p.folder)}</span>
                    </div>
                </td>
                <td>
                    <select class="select project-php-select" data-folder="${escapeHtml(p.folder)}" data-prev="${escapeHtml(p.php_version)}">
                        ${phpOptions}
                    </select>
                </td>
                <td><code>${rootLabel}</code></td>
                <td>
                    <div class="url-links">
                        <a class="btn btn-sm btn-secondary" href="${escapeHtml(p.http_url)}" target="_blank">HTTP ↗</a>
                        ${p.ssl ? `<a class="btn btn-sm btn-secondary" href="${escapeHtml(p.https_url)}" target="_blank">HTTPS ↗</a>` : ''}
                    </div>
                </td>
                <td>${statusHtml}</td>
                <td>
                    <div class="action-row">
                        ${phpInfo?.installed ? `<a class="btn btn-sm btn-secondary" href="/api/php/${encodeURIComponent(p.php_version)}/phpinfo" target="_blank">phpinfo</a>` : ''}
                        <button class="btn btn-sm btn-secondary btn-project-logs" data-folder="${escapeHtml(p.folder)}" data-domain="${escapeHtml(p.domain)}">${escapeHtml(t('projects.btnLogs'))}</button>
                        <button class="btn btn-sm btn-secondary btn-edit-project" data-folder="${escapeHtml(p.folder)}">${escapeHtml(t('projects.btnSettings'))}</button>
                        <button class="btn btn-sm btn-danger btn-delete-project" data-folder="${escapeHtml(p.folder)}" data-domain="${escapeHtml(p.domain)}">${escapeHtml(t('projects.btnDelete'))}</button>
                    </div>
                </td>
            </tr>`;
        })
        .join('');

    tbody.querySelectorAll('.project-php-select').forEach((sel) => {
        sel.addEventListener('change', async () => {
            const folder = sel.dataset.folder;
            const prev = sel.dataset.prev;
            const phpVersion = sel.value;
            const verInfo = state.overview?.php_versions?.[phpVersion];

            if (verInfo && !verInfo.installed) {
                if (verInfo.installing) {
                    openPhpInstallModal(phpVersion, folder);
                    sel.value = prev;
                    return;
                }
                const ok = confirm(t('projects.confirmInstallSwitch', { ver: phpVersion, folder }));
                if (!ok) {
                    sel.value = prev;
                    return;
                }
                sel.value = prev;
                await startPhpInstall(phpVersion, folder);
                return;
            }

            sel.disabled = true;
            try {
                await api(`/api/projects/${encodeURIComponent(folder)}`, {
                    method: 'PATCH',
                    body: JSON.stringify({ php_version: phpVersion }),
                });
                showToast(t('projects.switchedPhp', { folder, ver: phpVersion }), 'success');
                await loadOverview();
            } catch (err) {
                showToast(err.message, 'error');
                await loadOverview();
            }
        });
    });

    tbody.querySelectorAll('.btn-install-php-inline').forEach((btn) => {
        btn.addEventListener('click', () => startPhpInstall(btn.dataset.version, btn.dataset.folder));
    });

    tbody.querySelectorAll('.btn-edit-project').forEach((btn) => {
        btn.addEventListener('click', () => openEditProject(btn.dataset.folder));
    });

    tbody.querySelectorAll('.btn-project-logs').forEach((btn) => {
        btn.addEventListener('click', () => openProjectLogs(btn.dataset.folder, btn.dataset.domain));
    });

    tbody.querySelectorAll('.btn-delete-project').forEach((btn) => {
        btn.addEventListener('click', () => handleDeleteProject(btn.dataset.folder, btn.dataset.domain));
    });
}

function openEditProject(folder) {
    const project = state.overview?.projects.find((p) => p.folder === folder);
    if (!project) return;
    document.getElementById('edit-folder').value = project.folder;
    document.getElementById('edit-folder-title').textContent = project.folder;
    document.getElementById('edit-domain').value = project.domain;
    document.getElementById('edit-php').value = project.php_version;
    document.getElementById('edit-public-dir').value = project.public_dir || '';
    document.getElementById('edit-ssl').checked = Boolean(project.ssl);
    document.getElementById('edit-enabled').checked = Boolean(project.enabled);
    openModal('modal-edit-project');
}

async function handleDeleteProject(folder, domain) {
    const removeFiles = confirm(t('projects.confirmDelete', { domain, folder }));
    if (!removeFiles) {
        const onlyConfig = confirm(t('projects.confirmDeleteConfigOnly', { folder }));
        if (!onlyConfig) return;
    }
    try {
        await api(`/api/projects/${encodeURIComponent(folder)}?remove_files=${removeFiles}`, {
            method: 'DELETE',
        });
        showToast(t('projects.deleted', { domain }), 'success');
        await loadOverview();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// ==========================================
// Сервисы Docker
// ==========================================
function renderServices(data) {
    const container = document.getElementById('services-container');
    const grouped = {};
    for (const srv of data.services) {
        if (!grouped[srv.category]) grouped[srv.category] = [];
        grouped[srv.category].push(srv);
    }

    const categories = ['core', 'php', 'database', 'tools'];

    container.innerHTML = categories
        .filter((cat) => grouped[cat]?.length)
        .map((cat) => {
            const title = t(`cat.${cat}`);
            const cards = grouped[cat]
                .map((srv) => {
                    const isPhp = Boolean(srv.php_version);
                    const desc = state.lang === 'en'
                        ? (srv.description_en || srv.description)
                        : (srv.description_ru || srv.description);

                    let statusClass = 'status-stopped';
                    let statusLabel = `○ ${srv.status}`;

                    if (srv.installing) {
                        statusClass = 'status-installing';
                        statusLabel = t('services.installing');
                    } else if (srv.running) {
                        statusClass = 'status-running';
                        statusLabel = t('services.running');
                    } else if (srv.status === 'unavailable') {
                        statusClass = 'status-error';
                        statusLabel = t('services.unavailable');
                    } else if (srv.status === 'not_created') {
                        statusClass = isPhp ? 'status-not-installed' : 'status-stopped';
                        statusLabel = isPhp ? t('services.notInstalled') : t('services.notCreated');
                    }

                    let actionsHtml = '';
                    if (isPhp && srv.installing) {
                        actionsHtml = `<button class="btn btn-sm btn-secondary btn-watch-install" data-version="${srv.php_version}">${escapeHtml(t('services.watchInstall'))}</button>`;
                    } else if (isPhp && !srv.installed) {
                        actionsHtml = `<button class="btn btn-sm btn-primary btn-install-php" data-version="${srv.php_version}">${escapeHtml(t('services.downloadPhp', { ver: srv.php_version }))}</button>`;
                    } else {
                        actionsHtml = `
                            ${!srv.running ? `<button class="btn btn-sm btn-success btn-srv" data-id="${srv.id}" data-act="start">${escapeHtml(t('services.start'))}</button>` : ''}
                            ${srv.running && srv.id !== 'panel' ? `<button class="btn btn-sm btn-danger btn-srv" data-id="${srv.id}" data-act="stop">${escapeHtml(t('services.stop'))}</button>` : ''}
                            <button class="btn btn-sm btn-secondary btn-srv" data-id="${srv.id}" data-act="restart">${escapeHtml(t('services.restart'))}</button>
                            <button class="btn btn-sm btn-secondary btn-srv-logs" data-id="${srv.id}" data-name="${escapeHtml(srv.name)}">${escapeHtml(t('services.logs'))}</button>
                        `;
                    }

                    return `
                    <div class="service-card">
                        <div class="service-top">
                            <div>
                                <div class="service-name">${escapeHtml(srv.name)}</div>
                                <div class="service-desc">${escapeHtml(desc)}</div>
                            </div>
                            <span class="status-badge ${statusClass}">${escapeHtml(statusLabel)}</span>
                        </div>
                        <div class="service-meta">${escapeHtml(srv.container)}</div>
                        <div class="service-actions">${actionsHtml}</div>
                    </div>`;
                })
                .join('');

            return `
            <div>
                <div class="service-group-title">${escapeHtml(title)}</div>
                <div class="services-grid">${cards}</div>
            </div>`;
        })
        .join('');

    container.querySelectorAll('.btn-srv').forEach((btn) => {
        btn.addEventListener('click', async () => {
            const id = btn.dataset.id;
            const act = btn.dataset.act;
            btn.disabled = true;
            try {
                await api(`/api/services/${encodeURIComponent(id)}/${act}`, { method: 'POST' });
                showToast(t('services.actionDone', { id, act }), 'success');
                await loadOverview();
            } catch (err) {
                showToast(err.message, 'error');
                btn.disabled = false;
            }
        });
    });

    container.querySelectorAll('.btn-install-php').forEach((btn) => {
        btn.addEventListener('click', () => startPhpInstall(btn.dataset.version));
    });

    container.querySelectorAll('.btn-watch-install').forEach((btn) => {
        btn.addEventListener('click', () => openPhpInstallModal(btn.dataset.version));
    });

    container.querySelectorAll('.btn-srv-logs').forEach((btn) => {
        btn.addEventListener('click', () => openServiceLogs(btn.dataset.id, btn.dataset.name));
    });
}

// ==========================================
// Менеджер версий PHP (вкладка «Настройки PHP»)
// ==========================================
function renderPhpManager(data) {
    const grid = document.getElementById('php-versions-grid');
    if (!grid) return;

    grid.innerHTML = Object.entries(data.php_versions)
        .map(([ver, info]) => {
            let badge = `<span class="status-badge status-not-installed">${escapeHtml(t('php.statusNotInstalled'))}</span>`;
            if (info.installing) {
                badge = `<span class="status-badge status-installing">${escapeHtml(t('php.statusInstalling'))}</span>`;
            } else if (info.running) {
                badge = `<span class="status-badge status-running">${escapeHtml(t('php.statusRunning'))}</span>`;
            } else if (info.installed) {
                badge = `<span class="status-badge status-stopped">${escapeHtml(t('php.statusStopped'))}</span>`;
            }

            let buttons = '';
            if (info.installing) {
                buttons = `<button class="btn btn-sm btn-secondary btn-php-watch" data-version="${ver}">${escapeHtml(t('php.watchProgress'))}</button>`;
            } else if (!info.installed) {
                buttons = `<button class="btn btn-sm btn-primary btn-php-install" data-version="${ver}">${escapeHtml(t('php.installBtn', { ver }))}</button>`;
            } else {
                buttons = `
                    ${info.running
                        ? `<button class="btn btn-sm btn-danger btn-php-act" data-service="${info.service}" data-act="stop">${escapeHtml(t('services.stop'))}</button>`
                        : `<button class="btn btn-sm btn-success btn-php-act" data-service="${info.service}" data-act="start">${escapeHtml(t('services.start'))}</button>`
                    }
                    <a class="btn btn-sm btn-secondary" href="/api/php/${encodeURIComponent(ver)}/phpinfo" target="_blank">phpinfo ↗</a>
                    ${!info.is_default ? `<button class="btn btn-sm btn-secondary btn-php-uninstall" data-version="${ver}" title="${escapeHtml(t('php.uninstallTitle'))}">${escapeHtml(t('php.uninstallBtn'))}</button>` : ''}
                `;
            }

            return `
            <div class="service-card">
                <div class="service-top">
                    <div>
                        <div class="service-name">🐘 ${escapeHtml(info.label)}</div>
                        <div class="service-desc">${escapeHtml(info.is_default ? t('php.defaultDesc') : t('php.onDemandDesc'))}</div>
                    </div>
                    ${badge}
                </div>
                <div class="service-meta">${escapeHtml(info.image)}</div>
                <div class="service-actions">${buttons}</div>
            </div>`;
        })
        .join('');

    grid.querySelectorAll('.btn-php-install').forEach((btn) => {
        btn.addEventListener('click', () => startPhpInstall(btn.dataset.version));
    });

    grid.querySelectorAll('.btn-php-watch').forEach((btn) => {
        btn.addEventListener('click', () => openPhpInstallModal(btn.dataset.version));
    });

    grid.querySelectorAll('.btn-php-uninstall').forEach((btn) => {
        btn.addEventListener('click', () => handleUninstallPhp(btn.dataset.version));
    });

    grid.querySelectorAll('.btn-php-act').forEach((btn) => {
        btn.addEventListener('click', async () => {
            btn.disabled = true;
            try {
                await api(`/api/services/${encodeURIComponent(btn.dataset.service)}/${btn.dataset.act}`, { method: 'POST' });
                await loadOverview();
            } catch (err) {
                showToast(err.message, 'error');
                btn.disabled = false;
            }
        });
    });
}

async function loadPhpIni() {
    try {
        const data = await api('/api/php/ini');
        document.getElementById('php-ini-editor').value = data.content || '';
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// ==========================================
// Базы данных
// ==========================================
async function loadDatabases() {
    const tbody = document.getElementById('databases-tbody');
    const errBanner = document.getElementById('db-error-banner');
    const connBox = document.getElementById('db-connection-info');
    try {
        const data = await api('/api/databases');
        const c = data.connection;
        connBox.innerHTML = `
            <div class="info-list">
                <div class="info-item"><span class="info-key">${escapeHtml(t('db.hostInternal'))}</span><code>${escapeHtml(c.internal_host)}:${c.internal_port}</code></div>
                <div class="info-item"><span class="info-key">${escapeHtml(t('db.hostLocal'))}</span><code>${escapeHtml(c.host_address)}:${c.host_port}</code></div>
                <div class="info-item"><span class="info-key">${escapeHtml(t('db.userDev'))}</span><code>${escapeHtml(c.dev_user)} / ${escapeHtml(c.dev_password)}</code></div>
                <div class="info-item"><span class="info-key">${escapeHtml(t('db.userRoot'))}</span><code>${escapeHtml(c.root_user)} / ${escapeHtml(c.root_password)}</code></div>
            </div>
            <div style="margin-top:14px;">
                <a class="btn btn-secondary" href="${document.getElementById('link-pma').href}" target="_blank" style="width:100%;">${escapeHtml(t('db.openPma'))}</a>
            </div>
        `;

        if (!data.available) {
            errBanner.textContent = t('db.connError', { err: data.error });
            errBanner.classList.remove('hidden');
            tbody.innerHTML = `<tr><td colspan="5" class="empty">${escapeHtml(t('db.notResponding'))}</td></tr>`;
            return;
        }
        errBanner.classList.add('hidden');

        tbody.innerHTML = data.databases
            .map(
                (db) => `
            <tr>
                <td><strong>${escapeHtml(db.name)}</strong> ${db.system ? '<span class="badge-pill">system</span>' : ''}</td>
                <td><code>${escapeHtml(db.charset)}</code></td>
                <td>${db.tables_count}</td>
                <td>${db.size_mb.toFixed(2)} MB</td>
                <td class="text-right">
                    ${db.system ? '<span class="muted">—</span>' : `<button class="btn btn-sm btn-danger btn-drop-db" data-name="${escapeHtml(db.name)}">${escapeHtml(t('db.deleteBtn'))}</button>`}
                </td>
            </tr>`,
            )
            .join('');

        tbody.querySelectorAll('.btn-drop-db').forEach((btn) => {
            btn.addEventListener('click', async () => {
                const name = btn.dataset.name;
                if (!confirm(t('db.confirmDrop', { name }))) return;
                try {
                    await api(`/api/databases/${encodeURIComponent(name)}`, { method: 'DELETE' });
                    showToast(t('db.dropped', { name }), 'success');
                    loadDatabases();
                } catch (err) {
                    showToast(err.message, 'error');
                }
            });
        });
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// ==========================================
// Настройки приложения + DNS & SSL
// ==========================================
function renderSettingsUI() {
    const langSel = document.getElementById('setting-language');
    if (langSel) langSel.value = state.lang;

    const native = state.nativeHost;
    const inApp = Boolean(native?.isApp);

    document.getElementById('btn-open-native-settings')?.classList.toggle('hidden', !inApp);
    document.getElementById('settings-workspace-native')?.classList.toggle('hidden', !inApp);
    document.getElementById('settings-workspace-browser')?.classList.toggle('hidden', inApp);
    document.getElementById('settings-updates-section')?.classList.toggle('hidden', !inApp);
    document.getElementById('settings-env-actions')?.classList.toggle('hidden', !inApp);
    document.getElementById('settings-env-browser-note')?.classList.toggle('hidden', inApp);
    document.getElementById('btn-native-setup-dns')?.classList.toggle('hidden', !inApp);
    document.getElementById('btn-native-trust-ssl')?.classList.toggle('hidden', !inApp);
    document.getElementById('btn-native-sync-hosts')?.classList.toggle('hidden', !inApp);

    const dnsBadge = document.getElementById('native-dns-badge');
    if (dnsBadge) {
        if (inApp) {
            dnsBadge.classList.remove('hidden');
            dnsBadge.className = `status-badge ${native.dnsConfigured ? 'status-running' : 'status-stopped'}`;
            dnsBadge.textContent = native.dnsConfigured ? t('settings.dnsStatusOk') : t('settings.dnsStatusOff');
        } else {
            dnsBadge.classList.add('hidden');
        }
    }

    if (inApp) {
        const pathEl = document.getElementById('settings-workspace-path');
        if (pathEl) pathEl.textContent = native.workspacePath || '';
        const resetBtn = document.getElementById('btn-ws-reset');
        if (resetBtn) {
            resetBtn.disabled = native.workspacePath === native.defaultWorkspacePath;
        }
        const autoChk = document.getElementById('setting-auto-update');
        if (autoChk && typeof native.autoCheckUpdates === 'boolean') {
            autoChk.checked = native.autoCheckUpdates;
        }
        const updMeta = document.getElementById('settings-updates-meta');
        if (updMeta) {
            const verStr = t('settings.updatesVersion', { ver: native.appVersion || '1.0.0' });
            const lastStr = t('settings.updatesLastCheck', { date: native.lastUpdateCheck || '—' });
            updMeta.textContent = `${verStr} • ${lastStr}`;
        }
    }

    const envSource = native?.env || (state.overview ? {
        default_tld: state.overview.default_tld,
        default_php: state.overview.default_php,
        tz: state.overview.tz,
        http_port: state.overview.ports?.http,
        https_port: state.overview.ports?.https,
        panel_port: state.overview.ports?.panel,
        pma_port: state.overview.ports?.pma,
        mailpit_port: state.overview.ports?.mailpit,
        db_port: state.overview.ports?.db,
        redis_port: state.overview.ports?.redis,
        dns_port: state.overview.ports?.dns,
    } : null);

    const envFields = {
        'env-default-tld': envSource?.default_tld ?? 'loc',
        'env-default-php': envSource?.default_php ?? '8.4',
        'env-tz': envSource?.tz ?? 'Europe/Moscow',
        'env-http-port': envSource?.http_port ?? 80,
        'env-https-port': envSource?.https_port ?? 443,
        'env-panel-port': envSource?.panel_port ?? 8080,
        'env-pma-port': envSource?.pma_port ?? 8081,
        'env-mailpit-port': envSource?.mailpit_port ?? 8025,
        'env-db-port': envSource?.db_port ?? 3306,
        'env-redis-port': envSource?.redis_port ?? 6379,
        'env-dns-port': envSource?.dns_port ?? 10053,
    };

    for (const [id, val] of Object.entries(envFields)) {
        const el = document.getElementById(id);
        if (!el) continue;
        el.value = String(val);
        el.disabled = !inApp;
    }

    if (state.dnsSsl) {
        renderDnsSslDetails(state.dnsSsl);
    }
}

function renderDnsSslDetails(data) {
    const rp = document.getElementById('resolver-path');
    if (rp) rp.textContent = data.resolver_path;
    document.getElementById('resolver-content').textContent = data.resolver_content;
    document.getElementById('hosts-snippet').textContent = data.hosts_snippet;

    const nativeTrustRow = state.nativeHost?.isApp
        ? `<div class="info-item"><span class="info-key">${escapeHtml(t('settings.sslTrustStatus'))}</span><span>${state.nativeHost.sslTrusted ? escapeHtml(t('settings.sslTrusted')) : escapeHtml(t('settings.sslUntrusted'))}</span></div>`
        : '';

    document.getElementById('ssl-details').innerHTML = `
        <div class="info-item"><span class="info-key">${escapeHtml(t('settings.sslCertStatus'))}</span><span>${data.ssl.ready ? escapeHtml(t('settings.sslGenerated')) : escapeHtml(t('settings.sslNotGenerated'))}</span></div>
        ${nativeTrustRow}
        <div class="info-item"><span class="info-key">${escapeHtml(t('settings.sslRootCa'))}</span><code>${escapeHtml(data.ssl.ca_path_relative)}</code></div>
        <div class="info-item"><span class="info-key">${escapeHtml(t('settings.dnsServerPort'))}</span><code>127.0.0.1:${data.dns_port}</code></div>
    `;
}

async function loadDnsSsl() {
    try {
        const data = await api('/api/dns-ssl');
        state.dnsSsl = data;
        renderDnsSslDetails(data);
    } catch (err) {
        showToast(err.message, 'error');
    }
}

function collectAndSaveEnv(applyRestart) {
    const tld = (document.getElementById('env-default-tld').value || '').trim().replace(/^\.+|\.+$/g, '').toLowerCase();
    if (!/^[a-z0-9]+$/.test(tld)) {
        showToast(t('settings.envInvalidTld'), 'error');
        return;
    }
    const readPort = (id) => {
        const n = parseInt(document.getElementById(id).value, 10);
        return Number.isInteger(n) && n >= 1 && n <= 65535 ? n : null;
    };
    const env = {
        default_tld: tld,
        default_php: document.getElementById('env-default-php').value,
        tz: (document.getElementById('env-tz').value || 'UTC').trim(),
        http_port: readPort('env-http-port'),
        https_port: readPort('env-https-port'),
        panel_port: readPort('env-panel-port'),
        pma_port: readPort('env-pma-port'),
        mailpit_port: readPort('env-mailpit-port'),
        db_port: readPort('env-db-port'),
        redis_port: readPort('env-redis-port'),
        dns_port: readPort('env-dns-port'),
    };
    const portKeys = ['http_port', 'https_port', 'panel_port', 'pma_port', 'mailpit_port', 'db_port', 'redis_port', 'dns_port'];
    if (portKeys.some((k) => env[k] === null)) {
        showToast(t('settings.envInvalidPort'), 'error');
        return;
    }
    postNative({ action: 'saveEnv', env, applyRestart });
}

// ==========================================
// Логи (модалка)
// ==========================================
async function refreshLogsModal() {
    if (!state.logsTarget) return;
    const pre = document.getElementById('logs-content');
    pre.textContent = t('modal.logs.loading');
    try {
        if (state.logsTarget.kind === 'service') {
            const data = await api(`/api/services/${encodeURIComponent(state.logsTarget.id)}/logs?tail=200`);
            pre.textContent = data.logs || t('common.empty');
        } else {
            const data = await api(
                `/api/projects/${encodeURIComponent(state.logsTarget.id)}/logs?log_type=${state.logsTarget.logType}&tail=200`,
            );
            pre.textContent = data.content || t('common.empty');
        }
        pre.scrollTop = pre.scrollHeight;
    } catch (err) {
        pre.textContent = t('modal.logs.error', { err: err.message });
    }
}

function openServiceLogs(id, name) {
    state.logsTarget = { kind: 'service', id };
    document.getElementById('logs-modal-title').textContent = t('modal.logs.serviceTitle', { name });
    document.getElementById('logs-type-switch').classList.add('hidden');
    openModal('modal-logs');
    refreshLogsModal();
}

function openProjectLogs(folder, domain) {
    state.logsTarget = { kind: 'project', id: folder, logType: 'error' };
    document.getElementById('logs-modal-title').textContent = t('modal.logs.projectTitle', { domain });
    const sw = document.getElementById('logs-type-switch');
    sw.classList.remove('hidden');
    sw.querySelectorAll('button').forEach((b) => b.classList.toggle('active', b.dataset.logType === 'error'));
    openModal('modal-logs');
    refreshLogsModal();
}

// ==========================================
// Модалки
// ==========================================
function openModal(id) {
    document.getElementById(id).classList.remove('hidden');
}

function closeModal(id) {
    document.getElementById(id).classList.add('hidden');
    if (id === 'modal-php-install') {
        stopInstallPolling();
    }
}

// ==========================================
// Инициализация событий
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
    applyStaticTranslations();

    document.querySelectorAll('.nav-item').forEach((btn) => {
        btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });

    document.querySelectorAll('[data-close-modal]').forEach((btn) => {
        btn.addEventListener('click', () => closeModal(btn.dataset.closeModal));
    });

    document.querySelectorAll('.modal-backdrop').forEach((backdrop) => {
        backdrop.addEventListener('click', (e) => {
            if (e.target === backdrop) closeModal(backdrop.id);
        });
    });

    document.getElementById('btn-refresh-all').addEventListener('click', () => {
        loadOverview();
        if (state.activeTab === 'databases') loadDatabases();
        if (state.activeTab === 'settings') {
            loadDnsSsl();
            postNative({ action: 'getNativeState' });
        }
    });

    document.getElementById('btn-reload-nginx').addEventListener('click', async () => {
        try {
            const res = await api('/api/nginx/reload', { method: 'POST' });
            showToast(res.message || t('common.nginxReloaded'), 'success');
        } catch (err) {
            showToast(err.message, 'error');
        }
    });

    document.getElementById('btn-open-create-project').addEventListener('click', () => {
        document.getElementById('form-create-project').reset();
        if (state.overview) {
            document.getElementById('create-php').value = state.overview.default_php;
        }
        document.getElementById('create-ssl').checked = true;
        openModal('modal-create-project');
    });

    document.getElementById('btn-sync-projects').addEventListener('click', async () => {
        try {
            const res = await api('/api/projects/sync', { method: 'POST' });
            showToast(t('projects.synced', { count: res.projects.length }), 'success');
            await loadOverview();
        } catch (err) {
            showToast(err.message, 'error');
        }
    });

    document.getElementById('project-search').addEventListener('input', () => {
        if (state.overview) renderProjects(state.overview);
    });

    // Создание проекта
    document.getElementById('form-create-project').addEventListener('submit', async (e) => {
        e.preventDefault();
        const phpVer = document.getElementById('create-php').value;
        const verInfo = state.overview?.php_versions?.[phpVer];
        try {
            const res = await api('/api/projects', {
                method: 'POST',
                body: JSON.stringify({
                    name: document.getElementById('create-name').value.trim(),
                    php_version: phpVer,
                    public_dir: document.getElementById('create-public-dir').value.trim(),
                    template: document.getElementById('create-template').value,
                    ssl: document.getElementById('create-ssl').checked,
                }),
            });
            closeModal('modal-create-project');
            showToast(t('projects.created', { domain: res.project.domain }), 'success');
            await loadOverview();
            if (verInfo && !verInfo.installed) {
                if (confirm(t('projects.confirmInstallNow', { ver: phpVer }))) {
                    await startPhpInstall(phpVer, res.project.folder);
                }
            }
        } catch (err) {
            showToast(err.message, 'error');
        }
    });

    // Редактирование проекта
    document.getElementById('form-edit-project').addEventListener('submit', async (e) => {
        e.preventDefault();
        const folder = document.getElementById('edit-folder').value;
        const phpVer = document.getElementById('edit-php').value;
        const verInfo = state.overview?.php_versions?.[phpVer];
        try {
            await api(`/api/projects/${encodeURIComponent(folder)}`, {
                method: 'PATCH',
                body: JSON.stringify({
                    domain: document.getElementById('edit-domain').value.trim(),
                    php_version: phpVer,
                    public_dir: document.getElementById('edit-public-dir').value.trim(),
                    ssl: document.getElementById('edit-ssl').checked,
                    enabled: document.getElementById('edit-enabled').checked,
                }),
            });
            closeModal('modal-edit-project');
            showToast(t('projects.saved'), 'success');
            await loadOverview();
            if (verInfo && !verInfo.installed) {
                if (confirm(t('projects.confirmInstallNow', { ver: phpVer }))) {
                    await startPhpInstall(phpVer, folder);
                }
            }
        } catch (err) {
            showToast(err.message, 'error');
        }
    });

    // Создание БД
    document.getElementById('form-create-db').addEventListener('submit', async (e) => {
        e.preventDefault();
        const input = document.getElementById('new-db-name');
        try {
            await api('/api/databases', {
                method: 'POST',
                body: JSON.stringify({ name: input.value.trim() }),
            });
            input.value = '';
            showToast(t('db.created'), 'success');
            loadDatabases();
        } catch (err) {
            showToast(err.message, 'error');
        }
    });

    // Сохранение php.ini
    document.getElementById('btn-save-php-ini').addEventListener('click', async () => {
        try {
            const res = await api('/api/php/ini', {
                method: 'PUT',
                body: JSON.stringify({
                    content: document.getElementById('php-ini-editor').value,
                    restart_php: document.getElementById('php-ini-restart').checked,
                }),
            });
            const restarted = res.restarted_php?.length
                ? t('php.iniRestarted', { list: res.restarted_php.join(', ') })
                : '';
            showToast(`${t('php.iniSaved')}${restarted}`, 'success');
        } catch (err) {
            showToast(err.message, 'error');
        }
    });

    // Консоль PHP/Composer
    document.getElementById('form-console').addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('btn-run-console');
        const out = document.getElementById('console-output');
        const cmd = document.getElementById('console-cmd').value.trim();
        if (!cmd) return;
        btn.disabled = true;
        out.textContent = `$ ${cmd}\n${t('console.running')}`;
        try {
            const res = await api('/api/console/exec', {
                method: 'POST',
                body: JSON.stringify({
                    php_version: document.getElementById('console-php').value,
                    folder: document.getElementById('console-project').value,
                    command: cmd,
                }),
            });
            out.textContent = `[PHP ${res.php_version} • ${res.workdir}] $ ${cmd}\n(exit code: ${res.exit_code})\n\n${res.output || t('console.noOutput')}`;
        } catch (err) {
            out.textContent = t('console.errorPrefix', { err: err.message });
        } finally {
            btn.disabled = false;
        }
    });

    document.querySelectorAll('.chip').forEach((chip) => {
        chip.addEventListener('click', () => {
            document.getElementById('console-cmd').value = chip.dataset.cmd;
            document.getElementById('form-console').dispatchEvent(new Event('submit'));
        });
    });

    // Логи
    document.getElementById('btn-refresh-logs').addEventListener('click', refreshLogsModal);
    document.querySelectorAll('#logs-type-switch button').forEach((btn) => {
        btn.addEventListener('click', () => {
            if (!state.logsTarget) return;
            state.logsTarget.logType = btn.dataset.logType;
            document.querySelectorAll('#logs-type-switch button').forEach((b) => {
                b.classList.toggle('active', b === btn);
            });
            refreshLogsModal();
        });
    });

    // Настройки приложения
    document.getElementById('setting-language').addEventListener('change', (e) => {
        setLanguage(e.target.value, false);
    });

    document.getElementById('btn-open-native-settings').addEventListener('click', () => {
        postNative({ action: 'openSettings' });
    });

    document.getElementById('btn-ws-choose').addEventListener('click', () => {
        postNative({ action: 'chooseWorkspace' });
    });

    document.getElementById('btn-ws-open').addEventListener('click', () => {
        postNative({ action: 'openWorkspace' });
    });

    document.getElementById('btn-ws-reset').addEventListener('click', () => {
        postNative({ action: 'resetWorkspace' });
    });

    document.getElementById('setting-auto-update').addEventListener('change', (e) => {
        postNative({ action: 'setAutoUpdate', enabled: Boolean(e.target.checked) });
    });

    document.getElementById('btn-check-updates').addEventListener('click', () => {
        postNative({ action: 'checkUpdates' });
    });

    document.getElementById('btn-env-save').addEventListener('click', () => {
        collectAndSaveEnv(false);
    });

    document.getElementById('btn-env-save-restart').addEventListener('click', () => {
        collectAndSaveEnv(true);
    });

    document.getElementById('btn-native-setup-dns').addEventListener('click', () => {
        postNative({ action: 'setupDns' });
    });

    document.getElementById('btn-native-trust-ssl').addEventListener('click', () => {
        postNative({ action: 'trustSsl' });
    });

    document.getElementById('btn-native-sync-hosts').addEventListener('click', () => {
        postNative({ action: 'syncHosts' });
    });

    // DNS & SSL
    document.getElementById('btn-regen-ssl').addEventListener('click', async () => {
        try {
            await api('/api/ssl/regenerate', { method: 'POST' });
            showToast(t('settings.sslRegenerated'), 'success');
            loadDnsSsl();
            loadOverview();
        } catch (err) {
            showToast(err.message, 'error');
        }
    });

    document.getElementById('btn-copy-hosts').addEventListener('click', () => {
        copyText(document.getElementById('hosts-snippet').textContent);
    });

    document.querySelectorAll('.copy-btn').forEach((btn) => {
        btn.addEventListener('click', () => copyText(btn.dataset.copy));
    });

    loadOverview();
    postNative({ action: 'getNativeState' });
});
