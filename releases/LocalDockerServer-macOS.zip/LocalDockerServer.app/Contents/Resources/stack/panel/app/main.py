from __future__ import annotations

import json
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

from .config import (
    APP_SETTINGS_FILE,
    CONFIG_DIR,
    DB_PORT,
    DEFAULT_PHP_VERSION,
    DEFAULT_TLD,
    DNS_PORT,
    HTTP_PORT,
    HTTPS_PORT,
    MAILPIT_PORT,
    PANEL_PORT,
    PHP_CUSTOM_INI_FILE,
    PHP_VERSIONS,
    PMA_PORT,
    REDIS_PORT,
    SYSTEM_DOMAINS,
    TZ,
)
from .db_manager import create_database, drop_database, list_databases
from .docker_manager import docker_manager
from .project_manager import (
    create_project,
    delete_project,
    ensure_directories,
    generate_hosts_snippet,
    get_project_logs,
    regenerate_nginx_configs,
    sync_projects,
    update_project,
)
from .ssl_manager import generate_server_cert, get_ssl_status

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
SUPPORTED_LANGUAGES = {"ru", "en"}


def load_app_settings() -> dict[str, Any]:
    defaults = {"language": "ru"}
    if not APP_SETTINGS_FILE.exists():
        return defaults
    try:
        data = json.loads(APP_SETTINGS_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            lang = data.get("language")
            if lang in SUPPORTED_LANGUAGES:
                defaults["language"] = lang
    except Exception:
        pass
    return defaults


def save_app_settings(updates: dict[str, Any]) -> dict[str, Any]:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    current = load_app_settings()
    if "language" in updates and updates["language"] is not None:
        lang = str(updates["language"]).strip().lower()
        if lang not in SUPPORTED_LANGUAGES:
            raise ValueError(f"Unsupported language: {lang}")
        current["language"] = lang
    APP_SETTINGS_FILE.write_text(
        json.dumps(current, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return current


@asynccontextmanager
async def lifespan(_app: FastAPI):
    ensure_directories()
    regenerate_nginx_configs(regen_ssl=False)
    docker_manager.reload_nginx()
    yield


app = FastAPI(title="LocalDockerServer Control Panel", version="1.0.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")


# ==========================================
# Pydantic схемы запросов
# ==========================================
class CreateProjectRequest(BaseModel):
    name: str
    php_version: str = DEFAULT_PHP_VERSION
    public_dir: str = ""
    ssl: bool = True
    template: str = "basic"


class UpdateProjectRequest(BaseModel):
    domain: str | None = None
    php_version: str | None = None
    public_dir: str | None = None
    ssl: bool | None = None
    enabled: bool | None = None


class CreateDatabaseRequest(BaseModel):
    name: str


class PhpIniUpdateRequest(BaseModel):
    content: str
    restart_php: bool = True


class ExecCommandRequest(BaseModel):
    php_version: str = DEFAULT_PHP_VERSION
    folder: str = ""
    command: str


class AppSettingsUpdateRequest(BaseModel):
    language: str | None = None


# ==========================================
# Health & UI
# ==========================================
@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# ==========================================
# Настройки приложения
# ==========================================
@app.get("/api/settings")
def api_get_settings() -> dict[str, Any]:
    return {
        **load_app_settings(),
        "default_tld": DEFAULT_TLD,
        "default_php": DEFAULT_PHP_VERSION,
        "tz": TZ,
        "ports": {
            "http": HTTP_PORT,
            "https": HTTPS_PORT,
            "panel": PANEL_PORT,
            "pma": PMA_PORT,
            "mailpit": MAILPIT_PORT,
            "db": DB_PORT,
            "redis": REDIS_PORT,
            "dns": DNS_PORT,
        },
    }


@app.patch("/api/settings")
def api_update_settings(payload: AppSettingsUpdateRequest) -> dict[str, Any]:
    try:
        saved = save_app_settings({"language": payload.language})
        return {"ok": True, **saved}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


# ==========================================
# Общий статус и система
# ==========================================
@app.get("/api/overview")
def api_overview() -> dict[str, Any]:
    projects = sync_projects()
    services = docker_manager.list_services()
    php_versions_status = docker_manager.get_php_versions_status()
    running_count = sum(1 for s in services if s["running"])
    installed_count = sum(1 for s in services if s["installed"])
    php_running = [v for v, info in php_versions_status.items() if info["running"]]
    php_installed = [v for v, info in php_versions_status.items() if info["installed"]]

    return {
        "docker_available": docker_manager.is_available(),
        "default_tld": DEFAULT_TLD,
        "default_php": DEFAULT_PHP_VERSION,
        "tz": TZ,
        "settings": load_app_settings(),
        "ports": {
            "http": HTTP_PORT,
            "https": HTTPS_PORT,
            "panel": PANEL_PORT,
            "pma": PMA_PORT,
            "mailpit": MAILPIT_PORT,
            "db": DB_PORT,
            "redis": REDIS_PORT,
            "dns": DNS_PORT,
        },
        "php_versions": php_versions_status,
        "system_domains": SYSTEM_DOMAINS,
        "ssl": get_ssl_status(),
        "stats": {
            "projects_total": len(projects),
            "projects_enabled": sum(1 for p in projects if p.get("enabled", True)),
            "services_total": len(services),
            "services_installed": installed_count,
            "services_running": running_count,
            "php_running_count": len(php_running),
            "php_installed_count": len(php_installed),
            "php_total_count": len(PHP_VERSIONS),
        },
        "projects": projects,
        "services": services,
    }


# ==========================================
# Проекты (Сайты)
# ==========================================
@app.get("/api/projects")
def api_list_projects():
    return {"projects": sync_projects()}


@app.post("/api/projects/sync")
def api_sync_projects():
    projects = regenerate_nginx_configs(regen_ssl=False)
    nginx_res = docker_manager.reload_nginx()
    return {"projects": projects, "nginx": nginx_res}


@app.post("/api/projects")
def api_create_project(payload: CreateProjectRequest):
    try:
        project = create_project(
            name=payload.name,
            php_version=payload.php_version,
            public_dir=payload.public_dir,
            ssl=payload.ssl,
            template=payload.template,
        )
        docker_manager.ensure_php_running(payload.php_version)
        nginx_res = docker_manager.reload_nginx()
        return {"ok": True, "project": project, "nginx": nginx_res}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.patch("/api/projects/{folder}")
def api_update_project(folder: str, payload: UpdateProjectRequest):
    try:
        project = update_project(
            folder=folder,
            domain=payload.domain,
            php_version=payload.php_version,
            public_dir=payload.public_dir,
            ssl=payload.ssl,
            enabled=payload.enabled,
        )
        if payload.php_version:
            docker_manager.ensure_php_running(payload.php_version)
        nginx_res = docker_manager.reload_nginx()
        return {"ok": True, "project": project, "nginx": nginx_res}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.delete("/api/projects/{folder}")
def api_delete_project(folder: str, remove_files: bool = False):
    try:
        res = delete_project(folder=folder, remove_files=remove_files)
        nginx_res = docker_manager.reload_nginx()
        return {**res, "nginx": nginx_res}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/projects/{folder}/logs")
def api_project_logs(folder: str, log_type: str = "error", tail: int = 120):
    try:
        content = get_project_logs(folder=folder, log_type=log_type, tail=tail)
        return {"folder": folder, "log_type": log_type, "content": content}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.get("/api/php/versions")
def api_php_versions():
    return {"versions": docker_manager.get_php_versions_status()}


@app.post("/api/php/{version}/install")
def api_install_php(version: str):
    try:
        return docker_manager.install_php_version(version)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/api/php/{version}/install/status")
def api_install_php_status(version: str):
    try:
        return docker_manager.get_php_install_status(version)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.delete("/api/php/{version}/uninstall")
def api_uninstall_php(version: str):
    projects = sync_projects()
    in_use = [p["domain"] for p in projects if p.get("php_version") == version]
    if in_use:
        raise HTTPException(
            status_code=400,
            detail=f"PHP {version} используется проектами: {', '.join(in_use)}. Сначала переключите их на другую версию.",
        )
    try:
        return docker_manager.uninstall_php_version(version)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/api/php/{version}/phpinfo", response_class=HTMLResponse)
def api_phpinfo(version: str):
    try:
        html = docker_manager.get_phpinfo_html(version)
        return HTMLResponse(content=html)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


# ==========================================
# Сервисы Docker
# ==========================================
@app.get("/api/services")
def api_list_services():
    return {
        "docker_available": docker_manager.is_available(),
        "services": docker_manager.list_services(),
    }


@app.post("/api/services/{service_id}/{action}")
def api_service_action(service_id: str, action: str):
    try:
        result = docker_manager.service_action(service_id, action)
        return {"ok": True, "service": result}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.post("/api/nginx/reload")
def api_reload_nginx():
    regenerate_nginx_configs(regen_ssl=False)
    res = docker_manager.reload_nginx()
    if not res["ok"]:
        raise HTTPException(status_code=500, detail=res["message"])
    return res


@app.get("/api/services/{service_id}/logs")
def api_service_logs(service_id: str, tail: int = 150):
    try:
        logs = docker_manager.get_logs(service_id, tail=tail)
        return {"service_id": service_id, "logs": logs}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


# ==========================================
# Базы данных
# ==========================================
@app.get("/api/databases")
def api_list_databases():
    return list_databases()


@app.post("/api/databases")
def api_create_database(payload: CreateDatabaseRequest):
    try:
        return create_database(payload.name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.delete("/api/databases/{name}")
def api_drop_database(name: str):
    try:
        return drop_database(name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


# ==========================================
# Настройки PHP (custom.ini)
# ==========================================
@app.get("/api/php/ini")
def api_get_php_ini():
    content = ""
    if PHP_CUSTOM_INI_FILE.exists():
        content = PHP_CUSTOM_INI_FILE.read_text(encoding="utf-8")
    return {"path": "config/php/custom.ini", "content": content}


@app.put("/api/php/ini")
def api_save_php_ini(payload: PhpIniUpdateRequest):
    PHP_CUSTOM_INI_FILE.parent.mkdir(parents=True, exist_ok=True)
    PHP_CUSTOM_INI_FILE.write_text(payload.content, encoding="utf-8")
    restarted = docker_manager.restart_php_services() if payload.restart_php else []
    return {"ok": True, "restarted_php": restarted}


# ==========================================
# DNS / SSL / Hosts
# ==========================================
@app.get("/api/dns-ssl")
def api_dns_ssl():
    return {
        "default_tld": DEFAULT_TLD,
        "dns_port": DNS_PORT,
        "ssl": get_ssl_status(),
        "hosts_snippet": generate_hosts_snippet(),
        "resolver_content": f"nameserver 127.0.0.1\nport {DNS_PORT}\n",
        "resolver_path": f"/etc/resolver/{DEFAULT_TLD}",
    }


@app.post("/api/ssl/regenerate")
def api_regenerate_ssl():
    projects = sync_projects()
    status = generate_server_cert(extra_domains=[p["domain"] for p in projects], force=True)
    regenerate_nginx_configs(regen_ssl=False)
    nginx_res = docker_manager.reload_nginx()
    return {"ok": True, "ssl": status, "nginx": nginx_res}


# ==========================================
# PHP CLI / Composer консоль
# ==========================================
@app.post("/api/console/exec")
def api_console_exec(payload: ExecCommandRequest):
    if not payload.command.strip():
        raise HTTPException(status_code=400, detail="Команда не может быть пустой.")
    try:
        return docker_manager.exec_in_php(
            php_version=payload.php_version,
            folder=payload.folder,
            command=payload.command,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
