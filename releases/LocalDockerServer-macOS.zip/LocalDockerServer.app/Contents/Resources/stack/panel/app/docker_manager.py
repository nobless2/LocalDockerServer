from __future__ import annotations

import threading
from datetime import datetime, timezone
from typing import Any

import docker
from docker.errors import DockerException, ImageNotFound, NotFound

from .config import DOCKER_PHP_DIR, PHP_VERSIONS, SERVICES_META, TZ


class DockerManager:
    def __init__(self) -> None:
        self._client: docker.DockerClient | None = None
        self._install_lock = threading.Lock()
        self._php_installs: dict[str, dict[str, Any]] = {}

    @property
    def client(self) -> docker.DockerClient | None:
        if self._client is None:
            try:
                self._client = docker.from_env()
            except DockerException:
                return None
        return self._client

    def is_available(self) -> bool:
        try:
            if not self.client:
                return False
            self.client.ping()
            return True
        except DockerException:
            return False

    def _get_container(self, container_name: str):
        if not self.client:
            return None
        try:
            return self.client.containers.get(container_name)
        except (NotFound, DockerException):
            return None

    def _image_exists(self, image_name: str) -> bool:
        if not self.client:
            return False
        try:
            self.client.images.get(image_name)
            return True
        except (ImageNotFound, DockerException):
            return False

    def _get_panel_host_context(self) -> dict[str, Any]:
        """Читает хостовые пути bind-монтирований и имя compose-проекта из самого контейнера localdockerserver-panel."""
        panel = self._get_container("localdockerserver-panel")
        if not panel:
            raise RuntimeError("Контейнер localdockerserver-panel не найден в Docker.")
        panel.reload()

        mounts_by_dest: dict[str, str] = {}
        for mount in panel.attrs.get("Mounts", []):
            dest = mount.get("Destination")
            src = mount.get("Source")
            if dest and src:
                mounts_by_dest[dest] = src

        projects_host = mounts_by_dest.get("/workspace/projects")
        config_host = mounts_by_dest.get("/workspace/config")
        runtime_host = mounts_by_dest.get("/workspace/runtime")
        if not (projects_host and config_host and runtime_host):
            raise RuntimeError("Не удалось определить хостовые пути монтирования из контейнера localdockerserver-panel.")

        labels = panel.attrs.get("Config", {}).get("Labels", {}) or {}
        compose_project = labels.get("com.docker.compose.project", "localdockerserver")
        networks = list((panel.attrs.get("NetworkSettings", {}).get("Networks", {}) or {}).keys())
        network_name = "localdockerserver-net" if "localdockerserver-net" in networks else (networks[0] if networks else "localdockerserver-net")

        return {
            "projects_host": projects_host,
            "config_host": config_host,
            "runtime_host": runtime_host,
            "compose_project": compose_project,
            "network_name": network_name,
        }

    def get_php_versions_status(self) -> dict[str, dict[str, Any]]:
        available = self.is_available()
        result: dict[str, dict[str, Any]] = {}

        with self._install_lock:
            jobs_snapshot = {k: dict(v) for k, v in self._php_installs.items()}

        for version, info in PHP_VERSIONS.items():
            container = self._get_container(info["container"]) if available else None
            image_exists = self._image_exists(info["image"]) if available else False
            container_exists = container is not None
            running = False
            status = "not_installed"
            if container is not None:
                container.reload()
                running = container.status == "running"
                status = container.status
            elif image_exists:
                status = "image_ready"

            job = jobs_snapshot.get(version)
            installing = bool(job and job.get("status") == "installing")
            if installing:
                status = "installing"

            result[version] = {
                "version": version,
                "service": info["service"],
                "container": info["container"],
                "image": info["image"],
                "label": info["label"],
                "is_default": info.get("is_default", False),
                "installed": container_exists or image_exists,
                "container_exists": container_exists,
                "image_exists": image_exists,
                "running": running,
                "status": status,
                "installing": installing,
                "install_status": job.get("status") if job else None,
                "install_error": job.get("error") if job else None,
            }

        return result

    def list_services(self) -> list[dict[str, Any]]:
        result = []
        available = self.is_available()
        php_statuses = self.get_php_versions_status()

        for meta in SERVICES_META:
            item = {
                **meta,
                "status": "unavailable" if not available else "not_created",
                "running": False,
                "installed": False,
                "installing": False,
                "started_at": None,
                "image": None,
            }
            php_ver = meta.get("php_version")
            if php_ver and php_ver in php_statuses:
                ps = php_statuses[php_ver]
                item["installed"] = ps["installed"]
                item["installing"] = ps["installing"]
                item["install_status"] = ps["install_status"]
                item["install_error"] = ps["install_error"]

            if available:
                container = self._get_container(meta["container"])
                if container:
                    container.reload()
                    state = container.attrs.get("State", {})
                    item["status"] = "installing" if item["installing"] else container.status
                    item["running"] = container.status == "running"
                    item["installed"] = True
                    item["started_at"] = state.get("StartedAt")
                    item["image"] = container.attrs.get("Config", {}).get("Image")
                elif item["installing"]:
                    item["status"] = "installing"
            result.append(item)

        return result

    def get_service_meta(self, service_id: str) -> dict[str, Any] | None:
        for meta in SERVICES_META:
            if meta["id"] == service_id:
                return meta
        return None

    def _create_php_container(self, version: str):
        if not self.client:
            raise RuntimeError("Docker недоступен.")
        info = PHP_VERSIONS[version]
        ctx = self._get_panel_host_context()

        existing = self._get_container(info["container"])
        if existing:
            return existing

        networking_config = self.client.api.create_networking_config({
            ctx["network_name"]: self.client.api.create_endpoint_config(
                aliases=[info["service"]]
            )
        })

        host_config = self.client.api.create_host_config(
            binds=[
                f"{ctx['projects_host']}:/var/www/projects:rw",
                f"{ctx['config_host']}/php/custom.ini:/usr/local/etc/php/conf.d/99-localdockerserver.ini:ro",
                f"{ctx['runtime_host']}/logs/php:/var/log/php:rw",
            ],
            restart_policy={"Name": "unless-stopped"},
        )

        created = self.client.api.create_container(
            image=info["image"],
            name=info["container"],
            environment={"TZ": TZ},
            labels={
                "com.docker.compose.project": ctx["compose_project"],
                "com.docker.compose.service": info["service"],
                "localdockerserver.managed": "true",
                "localdockerserver.php_version": version,
            },
            host_config=host_config,
            networking_config=networking_config,
        )
        return self.client.containers.get(created["Id"])

    def install_php_version(self, version: str) -> dict[str, Any]:
        if version not in PHP_VERSIONS:
            raise ValueError(f"Неподдерживаемая версия PHP: {version}")
        if not self.is_available():
            raise RuntimeError("Docker недоступен.")
        if not DOCKER_PHP_DIR.exists():
            raise RuntimeError(f"Не найден Dockerfile PHP: {DOCKER_PHP_DIR}")

        with self._install_lock:
            current = self._php_installs.get(version)
            if current and current.get("status") == "installing":
                return self.get_php_install_status(version)

            self._php_installs[version] = {
                "version": version,
                "status": "installing",
                "logs": [f"Запуск загрузки и сборки образа PHP {version}..."],
                "error": None,
                "started_at": datetime.now(timezone.utc).isoformat(),
                "finished_at": None,
            }

        thread = threading.Thread(target=self._run_php_install, args=(version,), daemon=True)
        thread.start()
        return self.get_php_install_status(version)

    def _append_install_log(self, version: str, message: str) -> None:
        clean = message.rstrip()
        if not clean:
            return
        with self._install_lock:
            job = self._php_installs.get(version)
            if job is not None:
                job["logs"].append(clean)
                if len(job["logs"]) > 600:
                    job["logs"] = job["logs"][-600:]

    def _run_php_install(self, version: str) -> None:
        info = PHP_VERSIONS[version]
        try:
            assert self.client is not None
            buildargs = {
                "PHP_VERSION": version,
                "XDEBUG_VERSION": info["xdebug_version"],
                "REDIS_VERSION": info["redis_version"],
            }

            if not self._image_exists(info["image"]):
                self._append_install_log(
                    version,
                    f"Сборка Docker-образа {info['image']} (php:{version}-fpm-alpine + расширения + Composer)...",
                )
                stream = self.client.api.build(
                    path=str(DOCKER_PHP_DIR),
                    dockerfile="Dockerfile",
                    tag=info["image"],
                    buildargs=buildargs,
                    rm=True,
                    decode=True,
                )
                for chunk in stream:
                    if "error" in chunk:
                        raise RuntimeError(chunk["error"])
                    if "errorDetail" in chunk and chunk["errorDetail"].get("message"):
                        raise RuntimeError(chunk["errorDetail"]["message"])
                    if "stream" in chunk:
                        for line in chunk["stream"].splitlines():
                            self._append_install_log(version, line)
                    elif "status" in chunk:
                        detail = chunk.get("progress") or ""
                        chunk_id = chunk.get("id") or ""
                        prefix = f"[{chunk_id}] " if chunk_id else ""
                        self._append_install_log(version, f"{prefix}{chunk['status']} {detail}".strip())
                self._append_install_log(version, f"Образ {info['image']} успешно собран.")
            else:
                self._append_install_log(version, f"Образ {info['image']} уже есть локально, создаём контейнер...")

            container = self._create_php_container(version)
            container.reload()
            if container.status != "running":
                self._append_install_log(version, f"Запуск контейнера {info['container']}...")
                container.start()
            self._append_install_log(version, f"Готово! PHP {version} установлен и запущен.")

            with self._install_lock:
                self._php_installs[version]["status"] = "done"
                self._php_installs[version]["finished_at"] = datetime.now(timezone.utc).isoformat()
        except Exception as exc:
            self._append_install_log(version, f"ОШИБКА: {exc}")
            with self._install_lock:
                self._php_installs[version]["status"] = "error"
                self._php_installs[version]["error"] = str(exc)
                self._php_installs[version]["finished_at"] = datetime.now(timezone.utc).isoformat()

    def get_php_install_status(self, version: str) -> dict[str, Any]:
        if version not in PHP_VERSIONS:
            raise ValueError(f"Неподдерживаемая версия PHP: {version}")
        with self._install_lock:
            job = self._php_installs.get(version)
            job_copy = {
                "version": version,
                "status": job["status"] if job else "idle",
                "logs": list(job["logs"]) if job else [],
                "error": job["error"] if job else None,
                "started_at": job["started_at"] if job else None,
                "finished_at": job["finished_at"] if job else None,
            }
        php_status = self.get_php_versions_status()[version]
        job_copy["installed"] = php_status["installed"]
        job_copy["running"] = php_status["running"]
        return job_copy

    def uninstall_php_version(self, version: str) -> dict[str, Any]:
        if version not in PHP_VERSIONS:
            raise ValueError(f"Неподдерживаемая версия PHP: {version}")
        info = PHP_VERSIONS[version]
        if info.get("is_default"):
            raise ValueError(f"Нельзя удалить базовую версию PHP {version}.")
        if not self.is_available() or not self.client:
            raise RuntimeError("Docker недоступен.")

        container = self._get_container(info["container"])
        if container:
            container.remove(force=True)
        try:
            self.client.images.remove(info["image"], force=True)
        except ImageNotFound:
            pass

        with self._install_lock:
            self._php_installs.pop(version, None)

        return {"ok": True, "version": version}

    def service_action(self, service_id: str, action: str) -> dict[str, Any]:
        meta = self.get_service_meta(service_id)
        if not meta:
            raise ValueError(f"Неизвестный сервис: {service_id}")
        if action not in ("start", "stop", "restart"):
            raise ValueError(f"Недопустимое действие: {action}")
        if service_id == "panel" and action == "stop":
            raise ValueError("Нельзя остановить саму панель управления из браузера. Используйте ./localdockerserver down в терминале.")

        container = self._get_container(meta["container"])
        if not container:
            php_ver = meta.get("php_version")
            if php_ver and action == "start" and self._image_exists(PHP_VERSIONS[php_ver]["image"]):
                container = self._create_php_container(php_ver)
            else:
                raise RuntimeError(f"Контейнер {meta['container']} не установлен. Сначала нажмите «Установить».")

        if action == "start":
            container.start()
        elif action == "stop":
            container.stop(timeout=8)
        elif action == "restart":
            container.restart(timeout=8)

        container.reload()
        return {
            "id": service_id,
            "container": meta["container"],
            "status": container.status,
            "running": container.status == "running",
        }

    def ensure_php_running(self, php_version: str) -> bool:
        info = PHP_VERSIONS.get(php_version)
        if not info:
            return False
        container = self._get_container(info["container"])
        if not container:
            if self._image_exists(info["image"]):
                container = self._create_php_container(php_version)
            else:
                return False
        container.reload()
        if container.status != "running":
            container.start()
        return True

    def restart_php_services(self) -> list[str]:
        restarted = []
        for version, info in PHP_VERSIONS.items():
            container = self._get_container(info["container"])
            if container:
                container.reload()
                if container.status == "running":
                    container.restart(timeout=8)
                    restarted.append(version)
        return restarted

    def reload_nginx(self) -> dict[str, Any]:
        container = self._get_container("localdockerserver-nginx")
        if not container:
            return {"ok": False, "message": "Контейнер Nginx не найден"}
        container.reload()
        if container.status != "running":
            return {"ok": False, "message": "Контейнер Nginx не запущен"}

        test_res = container.exec_run(["nginx", "-t"])
        if test_res.exit_code != 0:
            output = test_res.output.decode("utf-8", errors="replace").strip()
            return {"ok": False, "message": f"Ошибка конфигурации Nginx:\n{output}"}

        reload_res = container.exec_run(["nginx", "-s", "reload"])
        output = reload_res.output.decode("utf-8", errors="replace").strip()
        if reload_res.exit_code != 0:
            return {"ok": False, "message": f"Не удалось перезагрузить Nginx:\n{output}"}

        return {"ok": True, "message": "Конфигурация Nginx успешно применена"}

    def get_logs(self, service_id: str, tail: int = 150) -> str:
        meta = self.get_service_meta(service_id)
        if not meta:
            raise ValueError(f"Неизвестный сервис: {service_id}")
        container = self._get_container(meta["container"])
        if not container:
            return f"Контейнер {meta['container']} ещё не установлен."
        raw = container.logs(tail=max(10, min(tail, 1000)), timestamps=False)
        return raw.decode("utf-8", errors="replace")

    def exec_in_php(self, php_version: str, folder: str, command: str) -> dict[str, Any]:
        info = PHP_VERSIONS.get(php_version)
        if not info:
            raise ValueError(f"Неподдерживаемая версия PHP: {php_version}")
        container = self._get_container(info["container"])
        if not container:
            raise RuntimeError(f"PHP {php_version} не установлен. Сначала дозагрузите его в панели управления.")
        container.reload()
        if container.status != "running":
            container.start()

        workdir = f"/var/www/projects/{folder}" if folder else "/var/www/projects"
        res = container.exec_run(
            ["bash", "-lc", command],
            workdir=workdir,
            demux=False,
        )
        output = res.output.decode("utf-8", errors="replace") if res.output else ""
        return {
            "exit_code": res.exit_code,
            "output": output,
            "php_version": php_version,
            "workdir": workdir,
        }

    def get_phpinfo_html(self, php_version: str) -> str:
        res = self.exec_in_php(php_version, "", "php -r 'phpinfo();'")
        return res["output"]


docker_manager = DockerManager()
