from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Iterable

from .config import CERTS_DIR, DEFAULT_TLD

CA_KEY = CERTS_DIR / "localdockerserver-root-ca.key"
CA_CERT = CERTS_DIR / "localdockerserver-root-ca.crt"
SERVER_KEY = CERTS_DIR / "server.key"
SERVER_CERT = CERTS_DIR / "server.crt"
SERVER_CSR = CERTS_DIR / "server.csr"
EXT_FILE = CERTS_DIR / "san.ext"


def _run_openssl(args: list[str]) -> None:
    res = subprocess.run(
        ["openssl", *args],
        capture_output=True,
        text=True,
        check=False,
    )
    if res.returncode != 0:
        raise RuntimeError(f"OpenSSL error: {res.stderr.strip() or res.stdout.strip()}")


def certs_ready() -> bool:
    return CA_CERT.exists() and SERVER_CERT.exists() and SERVER_KEY.exists()


def ensure_ca() -> None:
    CERTS_DIR.mkdir(parents=True, exist_ok=True)
    if CA_KEY.exists() and CA_CERT.exists():
        return

    _run_openssl(["genrsa", "-out", str(CA_KEY), "2048"])
    _run_openssl([
        "req",
        "-x509",
        "-new",
        "-nodes",
        "-key", str(CA_KEY),
        "-sha256",
        "-days", "3650",
        "-subj", "/C=RU/O=LocalDockerServer Local Dev/CN=LocalDockerServer Local Root CA",
        "-out", str(CA_CERT),
    ])


def generate_server_cert(extra_domains: Iterable[str] = (), force: bool = False) -> dict:
    ensure_ca()
    if not force and SERVER_CERT.exists() and SERVER_KEY.exists() and not extra_domains:
        return get_ssl_status()

    sans = {
        "localhost",
        f"*.{DEFAULT_TLD}",
        "*.loc",
        "*.local",
        "*.test",
        f"panel.{DEFAULT_TLD}",
        f"pma.{DEFAULT_TLD}",
        f"mail.{DEFAULT_TLD}",
    }
    for domain in extra_domains:
        d = domain.strip().lower()
        if d:
            sans.add(d)
            sans.add(f"*.{d}")

    san_lines = [f"DNS.{idx} = {name}" for idx, name in enumerate(sorted(sans), start=1)]
    san_lines.append("IP.1 = 127.0.0.1")

    ext_content = "\n".join([
        "authorityKeyIdentifier=keyid,issuer",
        "basicConstraints=CA:FALSE",
        "keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment",
        "extendedKeyUsage = serverAuth",
        "subjectAltName = @alt_names",
        "",
        "[alt_names]",
        *san_lines,
        "",
    ])
    EXT_FILE.write_text(ext_content, encoding="utf-8")

    _run_openssl(["genrsa", "-out", str(SERVER_KEY), "2048"])
    _run_openssl([
        "req",
        "-new",
        "-key", str(SERVER_KEY),
        "-subj", f"/C=RU/O=LocalDockerServer Local Dev/CN=*.{DEFAULT_TLD}",
        "-out", str(SERVER_CSR),
    ])
    _run_openssl([
        "x509",
        "-req",
        "-in", str(SERVER_CSR),
        "-CA", str(CA_CERT),
        "-CAkey", str(CA_KEY),
        "-CAcreateserial",
        "-out", str(SERVER_CERT),
        "-days", "825",
        "-sha256",
        "-extfile", str(EXT_FILE),
    ])

    if SERVER_CSR.exists():
        SERVER_CSR.unlink()

    return get_ssl_status()


def get_ssl_status() -> dict:
    return {
        "ready": certs_ready(),
        "ca_exists": CA_CERT.exists(),
        "server_cert_exists": SERVER_CERT.exists(),
        "ca_path_relative": "runtime/certs/localdockerserver-root-ca.crt",
        "trust_command_mac": "./localdockerserver trust-ssl",
    }
