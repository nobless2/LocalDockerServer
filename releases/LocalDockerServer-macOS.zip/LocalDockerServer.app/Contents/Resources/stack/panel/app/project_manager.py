from __future__ import annotations

import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import (
    CONFIG_DIR,
    DEFAULT_PHP_VERSION,
    DEFAULT_TLD,
    HTTP_PORT,
    HTTPS_PORT,
    KNOWN_TLDS,
    NGINX_CONFD_DIR,
    NGINX_LOGS_DIR,
    PHP_LOGS_DIR,
    PHP_VERSIONS,
    PROJECTS_CONFIG_FILE,
    PROJECTS_DIR,
    SYSTEM_DOMAINS,
)
from .ssl_manager import certs_ready, generate_server_cert

FOLDER_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$")
DOMAIN_RE = re.compile(r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$")


def ensure_directories() -> None:
    PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    NGINX_CONFD_DIR.mkdir(parents=True, exist_ok=True)
    NGINX_LOGS_DIR.mkdir(parents=True, exist_ok=True)
    PHP_LOGS_DIR.mkdir(parents=True, exist_ok=True)


def normalize_domain_from_folder(folder: str) -> str:
    lower = folder.lower().strip()
    if any(lower.endswith(tld) for tld in KNOWN_TLDS) or "." in lower:
        return lower
    return f"{lower}.{DEFAULT_TLD}"


def detect_public_dir(project_path: Path) -> str:
    for candidate in ("public", "web", "www"):
        if (project_path / candidate).is_dir() and (
            (project_path / candidate / "index.php").exists()
            or (project_path / candidate / "index.html").exists()
        ):
            return candidate
    return ""


def load_registry() -> dict[str, dict[str, Any]]:
    ensure_directories()
    if not PROJECTS_CONFIG_FILE.exists():
        return {}
    try:
        data = json.loads(PROJECTS_CONFIG_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def save_registry(data: dict[str, dict[str, Any]]) -> None:
    ensure_directories()
    PROJECTS_CONFIG_FILE.write_text(
        json.dumps(data, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def _format_url(scheme: str, domain: str) -> str:
    if scheme == "http" and HTTP_PORT != 80:
        return f"http://{domain}:{HTTP_PORT}"
    if scheme == "https" and HTTPS_PORT != 443:
        return f"https://{domain}:{HTTPS_PORT}"
    return f"{scheme}://{domain}"


def sync_projects() -> list[dict[str, Any]]:
    ensure_directories()
    registry = load_registry()
    discovered_folders = sorted(
        entry.name
        for entry in PROJECTS_DIR.iterdir()
        if entry.is_dir() and not entry.name.startswith(".")
    )

    changed = False

    # Добавляем новые папки, появившиеся в projects/
    for folder in discovered_folders:
        if folder not in registry:
            project_path = PROJECTS_DIR / folder
            registry[folder] = {
                "folder": folder,
                "domain": normalize_domain_from_folder(folder),
                "php_version": DEFAULT_PHP_VERSION,
                "public_dir": detect_public_dir(project_path),
                "ssl": True,
                "enabled": True,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
            changed = True

    # Удаляем записи о папках, которые физически удалили
    for folder in list(registry.keys()):
        if folder not in discovered_folders:
            del registry[folder]
            changed = True

    if changed or not PROJECTS_CONFIG_FILE.exists():
        save_registry(registry)

    result = []
    for folder in sorted(registry.keys()):
        item = dict(registry[folder])
        item["folder"] = folder
        if item.get("php_version") not in PHP_VERSIONS:
            item["php_version"] = DEFAULT_PHP_VERSION
        item["http_url"] = _format_url("http", item["domain"])
        item["https_url"] = _format_url("https", item["domain"])
        item["exists"] = (PROJECTS_DIR / folder).is_dir()
        result.append(item)

    return result


def _render_system_nginx_conf(use_ssl: bool) -> str:
    ssl_block = ""
    if use_ssl:
        ssl_block = """    listen 443 ssl;
    ssl_certificate /etc/nginx/certs/server.crt;
    ssl_certificate_key /etc/nginx/certs/server.key;
"""

    return f"""# Автоматически сгенерировано LocalDockerServer — системные домены

server {{
    listen 80 default_server;
{ssl_block}    server_name panel.{DEFAULT_TLD} localdockerserver.{DEFAULT_TLD} localhost _;

    location / {{
        set $upstream_panel panel:8000;
        proxy_pass http://$upstream_panel;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }}
}}

server {{
    listen 80;
{ssl_block}    server_name pma.{DEFAULT_TLD};

    location / {{
        set $upstream_pma phpmyadmin:80;
        proxy_pass http://$upstream_pma;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }}
}}

server {{
    listen 80;
{ssl_block}    server_name mail.{DEFAULT_TLD};

    location / {{
        set $upstream_mailpit mailpit:8025;
        proxy_pass http://$upstream_mailpit;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }}
}}
"""


def _render_project_nginx_conf(project: dict[str, Any], use_ssl: bool) -> str:
    domain = project["domain"]
    folder = project["folder"]
    public_dir = (project.get("public_dir") or "").strip("/")
    root_path = f"/var/www/projects/{folder}"
    if public_dir:
        root_path = f"{root_path}/{public_dir}"

    php_version = project.get("php_version", DEFAULT_PHP_VERSION)
    php_service = PHP_VERSIONS.get(php_version, PHP_VERSIONS[DEFAULT_PHP_VERSION])["service"]
    safe_log_name = re.sub(r"[^a-zA-Z0-9._-]", "_", domain)

    ssl_block = ""
    if use_ssl and project.get("ssl", True):
        ssl_block = """    listen 443 ssl;
    ssl_certificate /etc/nginx/certs/server.crt;
    ssl_certificate_key /etc/nginx/certs/server.key;
"""

    return f"""# LocalDockerServer VirtualHost: {domain} (PHP {php_version})
server {{
    listen 80;
{ssl_block}    server_name {domain} www.{domain};

    root {root_path};
    index index.php index.html index.htm;

    access_log /var/log/nginx/{safe_log_name}.access.log main;
    error_log  /var/log/nginx/{safe_log_name}.error.log warn;

    charset utf-8;

    location / {{
        try_files $uri $uri/ /index.php?$query_string;
    }}

    location ~ \\.php$ {{
        try_files $uri =404;
        set $php_upstream {php_service}:9000;
        fastcgi_pass $php_upstream;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param PATH_INFO $fastcgi_path_info;
        fastcgi_read_timeout 300;
    }}

    location ~ /\\.(?!well-known).* {{
        deny all;
    }}
}}
"""


def regenerate_nginx_configs(regen_ssl: bool = False) -> list[dict[str, Any]]:
    projects = sync_projects()
    all_domains = [p["domain"] for p in projects]

    if regen_ssl or not certs_ready():
        try:
            generate_server_cert(extra_domains=all_domains, force=regen_ssl)
        except Exception:
            pass

    use_ssl = certs_ready()

    # Удаляем старые конфиги, чтобы не осталось «сирот»
    for conf_file in NGINX_CONFD_DIR.glob("*.conf"):
        conf_file.unlink()

    (NGINX_CONFD_DIR / "00-system.conf").write_text(
        _render_system_nginx_conf(use_ssl=use_ssl),
        encoding="utf-8",
    )

    for project in projects:
        if not project.get("enabled", True):
            continue
        safe_name = re.sub(r"[^a-zA-Z0-9._-]", "_", project["domain"])
        conf_path = NGINX_CONFD_DIR / f"site-{safe_name}.conf"
        conf_path.write_text(
            _render_project_nginx_conf(project, use_ssl=use_ssl),
            encoding="utf-8",
        )

    return projects


def _starter_index_php(domain: str, template: str) -> str:
    if template == "blank":
        return f"<?php\n\necho 'Hello from {domain}! PHP ' . PHP_VERSION;\n"

    return f"""<?php
$phpVersion = PHP_VERSION;
$sapi = PHP_SAPI;
$extensions = get_loaded_extensions();
sort($extensions);

$dbStatus = 'Не проверено';
$dbOk = false;
try {{
    $pdo = new PDO('mysql:host=db;port=3306;charset=utf8mb4', 'dev', 'dev', [
        PDO::ATTR_TIMEOUT => 2,
    ]);
    $dbVersion = $pdo->query('SELECT VERSION()')->fetchColumn();
    $dbStatus = 'Подключено (MariaDB ' . $dbVersion . ')';
    $dbOk = true;
}} catch (Throwable $e) {{
    $dbStatus = 'Ошибка: ' . $e->getMessage();
}}

$redisStatus = 'Расширение не загружено';
$redisOk = false;
if (class_exists('Redis')) {{
    try {{
        $redis = new Redis();
        $redis->connect('redis', 6379, 1.5);
        $redisStatus = 'Подключено (PONG: ' . $redis->ping() . ')';
        $redisOk = true;
    }} catch (Throwable $e) {{
        $redisStatus = 'Ошибка: ' . $e->getMessage();
    }}
}}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{domain} — LocalDockerServer</title>
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            min-height: 100vh;
            padding: 40px 20px;
        }}
        .wrap {{ max-width: 820px; margin: 0 auto; }}
        .card {{
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 16px;
            padding: 28px;
            margin-bottom: 20px;
        }}
        .badge {{
            display: inline-block;
            background: #2563eb;
            color: #fff;
            font-weight: 600;
            font-size: 13px;
            padding: 4px 12px;
            border-radius: 999px;
            margin-bottom: 12px;
        }}
        h1 {{ font-size: 28px; margin-bottom: 8px; }}
        p.sub {{ color: #94a3b8; margin-bottom: 20px; }}
        .grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 14px;
        }}
        .box {{
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 16px;
        }}
        .label {{ font-size: 12px; color: #94a3b8; text-transform: uppercase; letter-spacing: .04em; }}
        .val {{ font-size: 18px; font-weight: 600; margin-top: 6px; }}
        .ok {{ color: #4ade80; }}
        .err {{ color: #f87171; }}
        .links {{ display: flex; gap: 10px; flex-wrap: wrap; margin-top: 20px; }}
        .btn {{
            text-decoration: none;
            background: #334155;
            color: #f8fafc;
            padding: 9px 14px;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 500;
        }}
        .btn:hover {{ background: #475569; }}
        .ext {{
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin-top: 12px;
        }}
        .ext span {{
            background: #0f172a;
            border: 1px solid #334155;
            padding: 3px 8px;
            border-radius: 6px;
            font-size: 12px;
            color: #cbd5e1;
        }}
    </style>
</head>
<body>
    <div class="wrap">
        <div class="card">
            <span class="badge">LocalDockerServer • Локальный сайт</span>
            <h1><?= htmlspecialchars($_SERVER['HTTP_HOST'] ?? '{domain}') ?></h1>
            <p class="sub">Проект успешно работает в Docker-среде LocalDockerServer. Вы можете переключить версию PHP для этого сайта прямо в панели управления.</p>

            <div class="grid">
                <div class="box">
                    <div class="label">Версия PHP</div>
                    <div class="val" style="color:#60a5fa">PHP <?= htmlspecialchars($phpVersion) ?></div>
                </div>
                <div class="box">
                    <div class="label">База данных (MariaDB)</div>
                    <div class="val <?= $dbOk ? 'ok' : 'err' ?>" style="font-size:14px"><?= htmlspecialchars($dbStatus) ?></div>
                </div>
                <div class="box">
                    <div class="label">Redis</div>
                    <div class="val <?= $redisOk ? 'ok' : 'err' ?>" style="font-size:14px"><?= htmlspecialchars($redisStatus) ?></div>
                </div>
            </div>

            <div class="links">
                <a class="btn" href="http://panel.{DEFAULT_TLD}">Панель управления</a>
                <a class="btn" href="http://pma.{DEFAULT_TLD}">phpMyAdmin</a>
                <a class="btn" href="http://mail.{DEFAULT_TLD}">Mailpit (почта)</a>
            </div>
        </div>

        <div class="card">
            <div class="label">Загруженные расширения PHP (<?= count($extensions) ?>)</div>
            <div class="ext">
                <?php foreach ($extensions as $ext): ?>
                    <span><?= htmlspecialchars($ext) ?></span>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</body>
</html>
"""


def create_project(
    name: str,
    php_version: str = DEFAULT_PHP_VERSION,
    public_dir: str = "",
    ssl: bool = True,
    template: str = "basic",
) -> dict[str, Any]:
    ensure_directories()
    folder = name.strip().lower()
    if not FOLDER_RE.match(folder):
        raise ValueError("Имя проекта может содержать только латинские буквы, цифры, точки, дефисы и подчёркивания.")

    domain = normalize_domain_from_folder(folder)
    if not DOMAIN_RE.match(domain):
        raise ValueError(f"Некорректное доменное имя: {domain}")

    if domain in SYSTEM_DOMAINS:
        raise ValueError(f"Домен {domain} зарезервирован для системного сервиса LocalDockerServer.")

    if php_version not in PHP_VERSIONS:
        raise ValueError(f"Неподдерживаемая версия PHP: {php_version}")

    clean_public = public_dir.strip().strip("/")
    if ".." in clean_public:
        raise ValueError("Некорректный путь Document Root.")

    if template == "mvc" and not clean_public:
        clean_public = "public"

    project_path = PROJECTS_DIR / folder
    if project_path.exists():
        raise ValueError(f"Папка projects/{folder} уже существует.")

    target_dir = project_path / clean_public if clean_public else project_path
    target_dir.mkdir(parents=True, exist_ok=True)
    (target_dir / "index.php").write_text(_starter_index_php(domain, template), encoding="utf-8")

    registry = load_registry()
    registry[folder] = {
        "folder": folder,
        "domain": domain,
        "php_version": php_version,
        "public_dir": clean_public,
        "ssl": bool(ssl),
        "enabled": True,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    save_registry(registry)

    regenerate_nginx_configs(regen_ssl=True)
    return registry[folder]


def update_project(
    folder: str,
    domain: str | None = None,
    php_version: str | None = None,
    public_dir: str | None = None,
    ssl: bool | None = None,
    enabled: bool | None = None,
) -> dict[str, Any]:
    registry = load_registry()
    if folder not in registry:
        raise ValueError(f"Проект '{folder}' не найден.")

    item = registry[folder]
    domain_changed = False

    if domain is not None:
        clean_domain = domain.strip().lower()
        if not DOMAIN_RE.match(clean_domain):
            raise ValueError(f"Некорректный домен: {clean_domain}")
        if clean_domain in SYSTEM_DOMAINS:
            raise ValueError(f"Домен {clean_domain} зарезервирован системой.")
        if clean_domain != item["domain"]:
            item["domain"] = clean_domain
            domain_changed = True

    if php_version is not None:
        if php_version not in PHP_VERSIONS:
            raise ValueError(f"Неподдерживаемая версия PHP: {php_version}")
        item["php_version"] = php_version

    if public_dir is not None:
        clean_pub = public_dir.strip().strip("/")
        if ".." in clean_pub:
            raise ValueError("Некорректный путь Document Root.")
        item["public_dir"] = clean_pub

    if ssl is not None:
        item["ssl"] = bool(ssl)

    if enabled is not None:
        item["enabled"] = bool(enabled)

    registry[folder] = item
    save_registry(registry)
    regenerate_nginx_configs(regen_ssl=domain_changed)
    return item


def delete_project(folder: str, remove_files: bool = False) -> dict[str, Any]:
    registry = load_registry()
    if folder not in registry:
        raise ValueError(f"Проект '{folder}' не найден.")

    project_path = (PROJECTS_DIR / folder).resolve()
    projects_root = PROJECTS_DIR.resolve()
    if projects_root not in project_path.parents:
        raise ValueError("Некорректный путь проекта.")

    if remove_files and project_path.exists():
        shutil.rmtree(project_path)

    del registry[folder]
    save_registry(registry)
    regenerate_nginx_configs(regen_ssl=False)
    return {"ok": True, "folder": folder, "files_removed": remove_files}


def get_project_logs(folder: str, log_type: str = "error", tail: int = 120) -> str:
    registry = load_registry()
    if folder not in registry:
        raise ValueError(f"Проект '{folder}' не найден.")
    domain = registry[folder]["domain"]
    safe_log_name = re.sub(r"[^a-zA-Z0-9._-]", "_", domain)
    suffix = "access" if log_type == "access" else "error"
    log_file = NGINX_LOGS_DIR / f"{safe_log_name}.{suffix}.log"
    if not log_file.exists():
        return f"Файл лога {log_file.name} пока пуст или не создан."
    lines = log_file.read_text(encoding="utf-8", errors="replace").splitlines()
    return "\n".join(lines[-max(10, min(tail, 1000)):])


def generate_hosts_snippet() -> str:
    projects = sync_projects()
    domains = list(SYSTEM_DOMAINS)
    for p in projects:
        if p["domain"] not in domains:
            domains.append(p["domain"])
    lines = ["# >>> LocalDockerServer Local Domains >>>"]
    for d in domains:
        lines.append(f"127.0.0.1 {d}")
    lines.append("# <<< LocalDockerServer Local Domains <<<")
    return "\n".join(lines)
