from __future__ import annotations

import re
from typing import Any
import pymysql

from .config import DB_HOST, DB_PASSWORD, DB_PORT, DB_ROOT_PASSWORD, DB_USER

SYSTEM_DBS = {"information_schema", "mysql", "performance_schema", "sys"}
DB_NAME_RE = re.compile(r"^[a-zA-Z0-9_]{1,64}$")


def _connect():
    return pymysql.connect(
        host=DB_HOST,
        port=3306,
        user="root",
        password=DB_ROOT_PASSWORD,
        charset="utf8mb4",
        connect_timeout=3,
        read_timeout=5,
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True,
    )


def get_connection_info() -> dict[str, Any]:
    return {
        "internal_host": DB_HOST,
        "internal_port": 3306,
        "host_address": "127.0.0.1",
        "host_port": DB_PORT,
        "root_user": "root",
        "root_password": DB_ROOT_PASSWORD,
        "dev_user": DB_USER,
        "dev_password": DB_PASSWORD,
    }


def list_databases() -> dict[str, Any]:
    try:
        conn = _connect()
    except Exception as exc:
        return {
            "available": False,
            "error": str(exc),
            "databases": [],
            "connection": get_connection_info(),
        }

    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    s.SCHEMA_NAME AS name,
                    s.DEFAULT_CHARACTER_SET_NAME AS charset,
                    COUNT(t.TABLE_NAME) AS tables_count,
                    ROUND(COALESCE(SUM(t.DATA_LENGTH + t.INDEX_LENGTH), 0) / 1024 / 1024, 2) AS size_mb
                FROM information_schema.SCHEMATA s
                LEFT JOIN information_schema.TABLES t ON t.TABLE_SCHEMA = s.SCHEMA_NAME
                GROUP BY s.SCHEMA_NAME, s.DEFAULT_CHARACTER_SET_NAME
                ORDER BY s.SCHEMA_NAME
                """
            )
            rows = cur.fetchall()
            databases = [
                {
                    "name": row["name"],
                    "charset": row["charset"],
                    "tables_count": int(row["tables_count"] or 0),
                    "size_mb": float(row["size_mb"] or 0.0),
                    "system": row["name"] in SYSTEM_DBS,
                }
                for row in rows
            ]
        return {
            "available": True,
            "error": None,
            "databases": databases,
            "connection": get_connection_info(),
        }
    finally:
        conn.close()


def create_database(name: str) -> dict[str, Any]:
    clean = name.strip()
    if not DB_NAME_RE.match(clean):
        raise ValueError("Имя БД может содержать только латинские буквы, цифры и знак подчёркивания (1–64 символа).")
    if clean.lower() in SYSTEM_DBS:
        raise ValueError("Нельзя использовать системное имя базы данных.")

    conn = _connect()
    try:
        with conn.cursor() as cur:
            cur.execute(f"CREATE DATABASE `{clean}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
            cur.execute(f"GRANT ALL PRIVILEGES ON `{clean}`.* TO %s@'%%'", (DB_USER,))
            cur.execute("FLUSH PRIVILEGES")
        return {"ok": True, "name": clean}
    finally:
        conn.close()


def drop_database(name: str) -> dict[str, Any]:
    clean = name.strip()
    if not DB_NAME_RE.match(clean) or clean.lower() in SYSTEM_DBS:
        raise ValueError("Недопустимое или системное имя базы данных.")

    conn = _connect()
    try:
        with conn.cursor() as cur:
            cur.execute(f"DROP DATABASE IF EXISTS `{clean}`")
        return {"ok": True, "name": clean}
    finally:
        conn.close()
