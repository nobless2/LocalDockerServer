import os
from pathlib import Path

WORKSPACE_DIR = Path(os.getenv("LDS_WORKSPACE", "/workspace"))
PROJECTS_DIR = WORKSPACE_DIR / "projects"
CONFIG_DIR = WORKSPACE_DIR / "config"
RUNTIME_DIR = WORKSPACE_DIR / "runtime"
DOCKER_PHP_DIR = WORKSPACE_DIR / "docker" / "php"

PROJECTS_CONFIG_FILE = CONFIG_DIR / "projects.json"
APP_SETTINGS_FILE = CONFIG_DIR / "settings.json"
PHP_CUSTOM_INI_FILE = CONFIG_DIR / "php" / "custom.ini"
NGINX_CONFD_DIR = RUNTIME_DIR / "nginx" / "conf.d"
NGINX_LOGS_DIR = RUNTIME_DIR / "logs" / "nginx"
PHP_LOGS_DIR = RUNTIME_DIR / "logs" / "php"
CERTS_DIR = RUNTIME_DIR / "certs"

DEFAULT_TLD = os.getenv("LDS_DEFAULT_TLD", "loc").lstrip(".")
DEFAULT_PHP_VERSION = os.getenv("LDS_DEFAULT_PHP", "8.4")
TZ = os.getenv("TZ", "Europe/Moscow")

HTTP_PORT = int(os.getenv("LDS_HTTP_PORT", "80"))
HTTPS_PORT = int(os.getenv("LDS_HTTPS_PORT", "443"))
PANEL_PORT = int(os.getenv("LDS_PANEL_PORT", "8080"))
PMA_PORT = int(os.getenv("LDS_PMA_PORT", "8081"))
MAILPIT_PORT = int(os.getenv("LDS_MAILPIT_PORT", "8025"))
DB_PORT = int(os.getenv("LDS_DB_PORT", "3306"))
REDIS_PORT = int(os.getenv("LDS_REDIS_PORT", "6379"))
DNS_PORT = int(os.getenv("LDS_DNS_PORT", "10053"))

DB_HOST = os.getenv("DB_HOST", "db")
DB_ROOT_PASSWORD = os.getenv("DB_ROOT_PASSWORD", "root")
DB_USER = os.getenv("DB_USER", "dev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "dev")

PHP_VERSIONS = {
    "8.4": {
        "service": "php84",
        "container": "localdockerserver-php84",
        "image": "localdockerserver-php84:latest",
        "label": "PHP 8.4 (Latest)",
        "xdebug_version": "",
        "redis_version": "",
        "is_default": True,
    },
    "8.3": {
        "service": "php83",
        "container": "localdockerserver-php83",
        "image": "localdockerserver-php83:latest",
        "label": "PHP 8.3 (LTS)",
        "xdebug_version": "",
        "redis_version": "",
        "is_default": False,
    },
    "8.2": {
        "service": "php82",
        "container": "localdockerserver-php82",
        "image": "localdockerserver-php82:latest",
        "label": "PHP 8.2",
        "xdebug_version": "",
        "redis_version": "",
        "is_default": False,
    },
    "8.1": {
        "service": "php81",
        "container": "localdockerserver-php81",
        "image": "localdockerserver-php81:latest",
        "label": "PHP 8.1",
        "xdebug_version": "",
        "redis_version": "",
        "is_default": False,
    },
    "7.4": {
        "service": "php74",
        "container": "localdockerserver-php74",
        "image": "localdockerserver-php74:latest",
        "label": "PHP 7.4 (Legacy)",
        "xdebug_version": "3.1.6",
        "redis_version": "5.3.7",
        "is_default": False,
    },
}

SERVICES_META = [
    {
        "id": "nginx",
        "container": "localdockerserver-nginx",
        "name": "Nginx",
        "category": "core",
        "description": "Веб-сервер и маршрутизация *.loc + HTTPS",
        "description_ru": "Веб-сервер и маршрутизация *.loc + HTTPS",
        "description_en": "Web server and *.loc + HTTPS routing",
    },
    {
        "id": "dns",
        "container": "localdockerserver-dns",
        "name": "Wildcard DNS",
        "category": "core",
        "description": "Локальный DNS (*.loc → 127.0.0.1)",
        "description_ru": "Локальный DNS (*.loc → 127.0.0.1)",
        "description_en": "Local DNS (*.loc → 127.0.0.1)",
    },
    {
        "id": "panel",
        "container": "localdockerserver-panel",
        "name": "LocalDockerServer Panel",
        "category": "core",
        "description": "Панель управления сервером",
        "description_ru": "Панель управления сервером",
        "description_en": "Server control panel",
    },
    {
        "id": "php84",
        "container": "localdockerserver-php84",
        "name": "PHP 8.4 FPM",
        "category": "php",
        "php_version": "8.4",
        "description": "Последняя версия (ставится при первом запуске)",
        "description_ru": "Последняя версия (ставится при первом запуске)",
        "description_en": "Latest version (installed on first launch)",
    },
    {
        "id": "php83",
        "container": "localdockerserver-php83",
        "name": "PHP 8.3 FPM",
        "category": "php",
        "php_version": "8.3",
        "description": "PHP 8.3 + Composer + Xdebug + Redis",
        "description_ru": "PHP 8.3 + Composer + Xdebug + Redis",
        "description_en": "PHP 8.3 + Composer + Xdebug + Redis",
    },
    {
        "id": "php82",
        "container": "localdockerserver-php82",
        "name": "PHP 8.2 FPM",
        "category": "php",
        "php_version": "8.2",
        "description": "PHP 8.2 + Composer + Xdebug + Redis",
        "description_ru": "PHP 8.2 + Composer + Xdebug + Redis",
        "description_en": "PHP 8.2 + Composer + Xdebug + Redis",
    },
    {
        "id": "php81",
        "container": "localdockerserver-php81",
        "name": "PHP 8.1 FPM",
        "category": "php",
        "php_version": "8.1",
        "description": "PHP 8.1 + Composer + Xdebug + Redis",
        "description_ru": "PHP 8.1 + Composer + Xdebug + Redis",
        "description_en": "PHP 8.1 + Composer + Xdebug + Redis",
    },
    {
        "id": "php74",
        "container": "localdockerserver-php74",
        "name": "PHP 7.4 FPM",
        "category": "php",
        "php_version": "7.4",
        "description": "PHP 7.4 (Legacy) + Composer + Xdebug + Redis",
        "description_ru": "PHP 7.4 (Legacy) + Composer + Xdebug + Redis",
        "description_en": "PHP 7.4 (Legacy) + Composer + Xdebug + Redis",
    },
    {
        "id": "db",
        "container": "localdockerserver-db",
        "name": "MariaDB 10.11",
        "category": "database",
        "description": "СУБД (совместима с MySQL)",
        "description_ru": "СУБД (совместима с MySQL)",
        "description_en": "Database server (MySQL-compatible)",
    },
    {
        "id": "phpmyadmin",
        "container": "localdockerserver-phpmyadmin",
        "name": "phpMyAdmin",
        "category": "database",
        "description": "Веб-клиент для БД (pma.loc)",
        "description_ru": "Веб-клиент для БД (pma.loc)",
        "description_en": "Web database client (pma.loc)",
    },
    {
        "id": "redis",
        "container": "localdockerserver-redis",
        "name": "Redis 7",
        "category": "tools",
        "description": "Кэш и очереди в памяти",
        "description_ru": "Кэш и очереди в памяти",
        "description_en": "In-memory cache & queues",
    },
    {
        "id": "mailpit",
        "container": "localdockerserver-mailpit",
        "name": "Mailpit",
        "category": "tools",
        "description": "Перехват исходящей почты (mail.loc)",
        "description_ru": "Перехват исходящей почты (mail.loc)",
        "description_en": "Outgoing email catcher (mail.loc)",
    },
]

SYSTEM_DOMAINS = [
    f"panel.{DEFAULT_TLD}",
    f"pma.{DEFAULT_TLD}",
    f"mail.{DEFAULT_TLD}",
]

KNOWN_TLDS = (".loc", ".local", ".test")
